"""darkpool CLI entrypoint: `python -m darkpool_cli`."""
from darkpool_cli import main

if __name__ == "__main__":
    main()
