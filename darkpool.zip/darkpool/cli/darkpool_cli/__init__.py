"""darkpool — administrative CLI.

Subcommands:
    darkpool node list
    darkpool node info <node_id>
    darkpool node drain <node_id>
    darkpool node enable <node_id>
    darkpool node disable <node_id>
    darkpool node remove <node_id>
    darkpool node rotate <node_id>

    darkpool resources
    darkpool workloads
    darkpool workload create --image <img> --cpu <n> --ram <mb> --disk <gb>
    darkpool workload stop <id>

    darkpool info
    darkpool events [--tail N]

Configuration via env:
    DARKPOOL_MAIN_URL  (default http://localhost:8000)
    DARKPOOL_TOKEN     (admin session token)
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

import httpx


def _main_url() -> str:
    return os.getenv("DARKPOOL_MAIN_URL", "http://localhost:8000").rstrip("/")


def _token() -> str:
    return os.getenv("DARKPOOL_TOKEN", "")


def _headers() -> dict[str, str]:
    t = _token()
    return {"Authorization": f"Bearer {t}"} if t else {}


def _get(path: str, **kw) -> Any:
    r = httpx.get(f"{_main_url()}{path}", headers=_headers(), timeout=30.0, **kw)
    r.raise_for_status()
    return r.json()


def _post(path: str, body: dict | None = None) -> Any:
    r = httpx.post(f"{_main_url()}{path}", json=body or {}, headers=_headers(), timeout=30.0)
    r.raise_for_status()
    return r.json()


def _delete(path: str) -> Any:
    r = httpx.delete(f"{_main_url()}{path}", headers=_headers(), timeout=30.0)
    r.raise_for_status()
    return r.json()


def _fmt_bytes(n: int | None) -> str:
    if n is None:
        return "—"
    f = float(n)
    for unit in ["B", "K", "M", "G", "T", "P"]:
        if abs(f) < 1024:
            return f"{f:.1f}{unit}"
        f /= 1024
    return f"{f:.1f}E"


# --- Commands --------------------------------------------------------------

def cmd_node_list(args):
    data = _get("/api/nodes")
    if not data:
        print("(no nodes registered)")
        return
    print(f"{'NODE':<24}{'STATUS':<12}{'CPU':<6}{'RAM':<12}{'DISK':<12}{'RUNTIME':<10}")
    print("-" * 76)
    for n in data:
        print(
            f"{n['id']:<24}{n['status'].upper():<12}"
            f"{n['cpu_total']:<6}{_fmt_bytes(n['ram_total_bytes']):<12}"
            f"{_fmt_bytes(n['disk_total_bytes']):<12}"
            f"{(n.get('container_runtime') or '—'):<10}"
        )


def cmd_node_info(args):
    n = _get(f"/api/nodes/{args.node_id}")
    cap = _get(f"/api/resources/nodes/{args.node_id}")
    print(f"Node:        {n['id']}")
    print(f"UUID:        {n['node_uuid']}")
    print(f"Status:      {n['status'].upper()}")
    print(f"Hostname:    {n.get('hostname') or '—'}")
    print(f"OS:          {n.get('os') or '—'}")
    print(f"Kernel:      {n.get('kernel') or '—'}")
    print(f"Arch:        {n.get('arch') or '—'}")
    print(f"Runtime:     {n.get('container_runtime') or '—'}")
    print(f"CPU model:   {n.get('cpu_model') or '—'}")
    print(f"Capabilities:{n.get('capabilities', {})}")
    print()
    print(f"Physical:    CPU={n['cpu_total']}  RAM={_fmt_bytes(n['ram_total_bytes'])}  Disk={_fmt_bytes(n['disk_total_bytes'])}")
    print(f"Reserve:     CPU={n['cpu_reserve']}  RAM={_fmt_bytes(n['ram_reserve_bytes'])}  Disk={_fmt_bytes(n['disk_reserve_bytes'])}")
    print(f"Allocated:   CPU={cap['cpu_allocated']}  RAM={_fmt_bytes(cap['ram_allocated_bytes'])}  Disk={_fmt_bytes(cap['disk_allocated_bytes'])}")
    print(f"Available:   CPU={cap['cpu_available']}  RAM={_fmt_bytes(cap['ram_available_bytes'])}  Disk={_fmt_bytes(cap['disk_available_bytes'])}")
    print(f"Last heartbeat: {n.get('last_heartbeat_at') or 'never'}")


def cmd_node_drain(args):
    print(_post(f"/api/nodes/{args.node_id}/drain?on=true"))


def cmd_node_enable(args):
    print(_post(f"/api/nodes/{args.node_id}/drain?on=false"))


def cmd_node_disable(args):
    print(_delete(f"/api/nodes/{args.node_id}"))


def cmd_node_remove(args):
    print(_delete(f"/api/nodes/{args.node_id}"))


def cmd_node_rotate(args):
    out = _post(f"/api/nodes/{args.node_id}/rotate-token")
    print(f"New token for {args.node_id} (shown ONCE):")
    print(f"  {out['node_token']}")


def cmd_resources(args):
    s = _get("/api/resources/summary")
    print("\nDARKPOOL — Resource Pool\n")
    print("PHYSICAL (per-node):")
    for n in s["physical"]:
        print(f"  {n['node_id']:<20} CPU={n['cpu_total']:<4} RAM={_fmt_bytes(n['ram_total_bytes']):<10} Disk={_fmt_bytes(n['disk_total_bytes'])}")
    print()
    p = s["virtual_pool"]
    print("VIRTUAL POOL:")
    print(f"  CPU:     {p['cpu_total']} total / {p['cpu_allocated']} allocated / {p['cpu_available']} available")
    print(f"  RAM:     {_fmt_bytes(p['ram_total_bytes'])} total / {_fmt_bytes(p['ram_allocated_bytes'])} allocated / {_fmt_bytes(p['ram_available_bytes'])} available")
    print(f"  Disk:    {_fmt_bytes(p['disk_total_bytes'])} total / {_fmt_bytes(p['disk_allocated_bytes'])} allocated / {_fmt_bytes(p['disk_available_bytes'])} available")
    print()
    print(f"Overcommit CPU: {'ENABLED' if s['overcommit_cpu'] else 'DISABLED'}")
    print(f"Overcommit RAM: {'ENABLED' if s['overcommit_ram'] else 'DISABLED'}")
    print(f"\nNote: {s['note']}")


def cmd_workloads(args):
    data = _get("/api/workloads")
    if not data:
        print("(no workloads)")
        return
    print(f"{'ID':<14}{'IMAGE':<32}{'NODE':<16}{'CPU':<5}{'RAM':<10}{'STATUS':<10}")
    print("-" * 90)
    for w in data:
        print(
            f"{w['id'][:12]:<14}{w['image'][:30]:<32}"
            f"{(w.get('node_id') or '—')[:14]:<16}"
            f"{w['cpu_limit']:<5}{_fmt_bytes(w['ram_limit_bytes']):<10}"
            f"{w['status'].upper():<10}"
        )


def cmd_workload_create(args):
    body = {
        "image": args.image,
        "command": args.command,
        "env": dict(e.split("=", 1) for e in (args.env or [])),
        "cpu": args.cpu,
        "ram_mb": args.ram,
        "disk_gb": args.disk,
        "network": args.network or "bridge",
        "features_required": args.features or [],
    }
    out = _post("/api/workloads", body)
    print(f"Workload created:")
    print(f"  ID: {out['id']}")
    print(f"  Node: {out.get('node_id') or '(pending)'}")
    print(f"  Status: {out['status']}")
    print(f"  Workspace token: {out.get('workspace_token')}")


def cmd_workload_stop(args):
    print(_delete(f"/api/workloads/{args.workload_id}"))


def cmd_info(args):
    s = _get("/api/system/status")
    print("\nDARKPOOL\n" + "─" * 30)
    print(f"Main:           ONLINE")
    print(f"Workers:        {s['nodes_online']} ONLINE / {s['nodes_total']} total")
    print(f"Workloads:      {s['workloads_running']} running / {s['workloads_total']} total")
    p = s['pool']
    print()
    print("VIRTUAL POOL:")
    print(f"  CPU:     {p['cpu_total']} total ({p['cpu_available']} available)")
    print(f"  RAM:     {_fmt_bytes(p['ram_total_bytes'])} ({_fmt_bytes(p['ram_available_bytes'])} available)")
    print(f"  Disk:    {_fmt_bytes(p['disk_total_bytes'])} ({_fmt_bytes(p['disk_available_bytes'])} available)")
    print()


def cmd_events(args):
    data = _get(f"/api/events?hours={args.hours}")
    if args.tail:
        data = data[: args.tail]
    for e in data:
        print(f"[{e['timestamp'][:19]}] {e['type']:<24} {e['message']}")


def cmd_login(args):
    r = httpx.post(
        f"{_main_url()}/api/auth/login",
        json={"username": args.username, "password": args.password},
        timeout=10.0,
    )
    if r.status_code != 200:
        print(f"login failed: {r.text}", file=sys.stderr)
        sys.exit(1)
    data = r.json()
    print(f"export DARKPOOL_TOKEN={data['token']!r}")
    print(f"# Role: {data['role']}")


# --- Argparse -------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="darkpool", description="DarkPool administrative CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    # node
    np = sub.add_parser("node", help="Node management")
    nsub = np.add_subparsers(dest="node_cmd", required=True)
    nsub.add_parser("list").set_defaults(func=cmd_node_list)
    ni = nsub.add_parser("info"); ni.add_argument("node_id"); ni.set_defaults(func=cmd_node_info)
    nd = nsub.add_parser("drain"); nd.add_argument("node_id"); nd.set_defaults(func=cmd_node_drain)
    ne = nsub.add_parser("enable"); ne.add_argument("node_id"); ne.set_defaults(func=cmd_node_enable)
    nf = nsub.add_parser("disable"); nf.add_argument("node_id"); nf.set_defaults(func=cmd_node_disable)
    nr = nsub.add_parser("remove"); nr.add_argument("node_id"); nr.set_defaults(func=cmd_node_remove)
    nrt = nsub.add_parser("rotate"); nrt.add_argument("node_id"); nrt.set_defaults(func=cmd_node_rotate)

    # resources
    rp = sub.add_parser("resources"); rp.set_defaults(func=cmd_resources)
    # workloads
    wp = sub.add_parser("workloads"); wp.set_defaults(func=cmd_workloads)
    wc = sub.add_parser("workload"); wcsub = wc.add_subparsers(dest="workload_cmd", required=True)
    wcc = wcsub.add_parser("create")
    wcc.add_argument("--image", required=True)
    wcc.add_argument("--command")
    wcc.add_argument("--cpu", type=int, default=1)
    wcc.add_argument("--ram", type=int, default=512)
    wcc.add_argument("--disk", type=int, default=1)
    wcc.add_argument("--network")
    wcc.add_argument("--env", action="append", help="KEY=VAL (repeatable)")
    wcc.add_argument("--features", action="append")
    wcc.set_defaults(func=cmd_workload_create)
    wcs = wcsub.add_parser("stop"); wcs.add_argument("workload_id"); wcs.set_defaults(func=cmd_workload_stop)

    # info / events / login
    ip = sub.add_parser("info"); ip.set_defaults(func=cmd_info)
    ep = sub.add_parser("events"); ep.add_argument("--tail", type=int, default=50); ep.add_argument("--hours", type=int, default=24); ep.set_defaults(func=cmd_events)
    lp = sub.add_parser("login"); lp.add_argument("--username", required=True); lp.add_argument("--password", required=True); lp.set_defaults(func=cmd_login)

    return p


def main() -> None:
    args = build_parser().parse_args()
    try:
        args.func(args)
    except httpx.HTTPStatusError as e:
        print(f"API error: {e.response.status_code} {e.response.text}", file=sys.stderr)
        sys.exit(2)
    except httpx.ConnectError as e:
        print(f"connection error: {e}", file=sys.stderr)
        sys.exit(3)


if __name__ == "__main__":
    main()
