#!/usr/bin/env bash
# install-agent.sh — install darkpool-agent on a supporter VPS (Ubuntu 22.04+)
#
# Usage:
#   sudo MAIN_URL=https://main.example.com REGISTRATION_TOKEN=xxxx ./install-agent.sh
#   sudo ./install-agent.sh  # interactive
#
# This script:
#   1. Installs Docker + Python 3.11
#   2. Creates /opt/darkpool/agent with a Python venv
#   3. Copies the workspace-tools (darkpool-df, etc.) to /opt/darkpool/workspace-tools
#   4. Writes /etc/darkpool/agent.env (chmod 600) with node config
#   5. Installs the darkpool-agent.service systemd unit
#   6. Starts the agent; it will register with Main and start sending heartbeats
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="/opt/darkpool/agent"
VENV_DIR="$INSTALL_DIR/venv"
TOOLS_DIR="/opt/darkpool/workspace-tools"
CONF_DIR="/etc/darkpool"
SERVICE_FILE="/etc/systemd/system/darkpool-agent.service"
ENV_FILE="$CONF_DIR/agent.env"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: must be run as root (use sudo)." >&2
  exit 1
fi

echo "=== DarkPool Supporter Agent installer ==="
echo

# 1. System deps (Docker is REQUIRED for container workloads)
echo "[1/7] Installing system dependencies..."
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  python3.11 python3.11-venv python3-pip ca-certificates curl \
  >/dev/null

if ! command -v docker >/dev/null 2>&1; then
  echo "  Docker not found. Installing Docker via get.docker.com..."
  curl -fsSL https://get.docker.com -o /tmp/get-docker.sh
  sh /tmp/get-docker.sh
  systemctl enable --now docker
fi
echo "  done."

# 2. Layout
echo "[2/7] Creating $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR" "$TOOLS_DIR" "$CONF_DIR"
cp -r "$REPO_ROOT/agent"/* "$INSTALL_DIR/"
cp "$REPO_ROOT/workspace-tools"/* "$TOOLS_DIR"/
chmod +x "$TOOLS_DIR"/darkpool-*

# 3. Venv + deps
echo "[3/7] Creating Python venv..."
python3.11 -m venv "$VENV_DIR"
"$VENV_DIR/bin/pip" install --quiet --upgrade pip
"$VENV_DIR/bin/pip" install --quiet "$INSTALL_DIR"
echo "  done."

# 4. Config
echo "[4/7] Generating $ENV_FILE..."
read -r -p "  Main URL [https://main.example.com]: " MAIN_URL
MAIN_URL="${MAIN_URL:-https://main.example.com}"
read -r -p "  Registration token: " REGISTRATION_TOKEN
if [[ -z "$REGISTRATION_TOKEN" ]]; then
  echo "ERROR: registration token is required." >&2
  exit 1
fi
read -r -p "  Advertised name [worker-$(hostname -s)]: " ADVERTISED_NAME
ADVERTISED_NAME="${ADVERTISED_NAME:-worker-$(hostname -s)}"

cat > "$ENV_FILE" <<EOF
MAIN_URL=$MAIN_URL
REGISTRATION_TOKEN=$REGISTRATION_TOKEN
ADVERTISED_NAME=$ADVERTISED_NAME
HEARTBEAT_INTERVAL_SEC=10
RESOURCE_REFRESH_INTERVAL_SEC=5
CPU_RESERVE=1
RAM_RESERVE_MB=1024
DISK_RESERVE_GB=5
EOF
chmod 600 "$ENV_FILE"

# 5. systemd unit
echo "[5/7] Installing systemd unit..."
cat > "$SERVICE_FILE" <<UNIT
[Unit]
Description=DarkPool Supporter Agent
After=network-online.target docker.service
Wants=network-online.target docker.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$VENV_DIR/bin/python -m darkpool_agent
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable darkpool-agent >/dev/null

# 6. Start
echo "[6/7] Starting darkpool-agent.service..."
systemctl restart darkpool-agent
sleep 5

# 7. Verify
echo "[7/7] Verifying..."
if systemctl is-active --quiet darkpool-agent; then
  echo "  ✓ Agent is running."
else
  echo "  ! Agent failed to start. Check journal:"
  journalctl -u darkpool-agent -n 30 --no-pager
  exit 1
fi
echo
echo "=== Installation complete ==="
echo "Logs:       journalctl -u darkpool-agent -f"
echo "Config:     $ENV_FILE"
echo "Keys:       /etc/darkpool/agent.key (chmod 600)"
echo
echo "Wait a few seconds for the first heartbeat, then on Main run:"
echo "  darkpool node list"
