"""Shared pytest fixtures: in-memory SQLite + clean settings."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import pytest

# Add main/ and agent/ and cli/ to sys.path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "main"))
sys.path.insert(0, str(ROOT / "agent"))
sys.path.insert(0, str(ROOT / "cli"))

# Reset settings BEFORE importing any darkpool_main module
os.environ["ENV"] = "test"
os.environ["SECRET_KEY"] = "test-secret-key-for-pytest-only"
os.environ["DATABASE_URL"] = "sqlite:///:memory:"
os.environ["ADMIN_USERNAME"] = "admin"
os.environ["ADMIN_PASSWORD"] = "test-pass-123"
os.environ["ADMIN_EMAIL"] = "admin@test.local"
os.environ["NODE_REGISTRATION_TOKEN"] = "test-registration-token"


@pytest.fixture(autouse=True)
def _fresh_db():
    """Wipe all tables before each test (uses the in-memory engine)."""
    from darkpool_main.database import migrations
    from darkpool_main.database.models import Base
    from darkpool_main.database.session import get_engine

    Base.metadata.drop_all(get_engine())
    Base.metadata.create_all(get_engine())
    migrations._bootstrap_admin()
    yield
    # leave the engine intact for the next test
