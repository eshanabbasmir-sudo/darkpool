"""Security tests: invalid tokens, unauthorized, password hashing, RBAC."""
from __future__ import annotations

from fastapi.testclient import TestClient

from darkpool_main.app import create_app
from darkpool_main.auth.passwords import hash_password, verify_password
from darkpool_main.auth.node_auth import verify_node_token, verify_registration_token
from darkpool_main.database.session import db_session
from darkpool_main.node_manager.manager import register_node


def test_password_hash_roundtrip():
    h = hash_password("hunter2")
    assert verify_password("hunter2", h) is True
    assert verify_password("wrong", h) is False
    assert h != "hunter2"


def test_password_hash_unique_per_call():
    a = hash_password("same")
    b = hash_password("same")
    assert a != b  # different salt
    assert verify_password("same", a)
    assert verify_password("same", b)


def test_invalid_registration_token_rejected():
    assert verify_registration_token("wrong") is False


def test_api_register_requires_valid_token():
    client = TestClient(create_app())
    r = client.post("/api/nodes/register", json={
        "registration_token": "WRONG",
        "advertised_name": "worker-x",
        "public_key_pem": "fake",
        "cpu_total": 4, "ram_total_bytes": 8 * 1024 ** 3, "disk_total_bytes": 100 * 1024 ** 3,
    })
    assert r.status_code == 403


def test_api_heartbeat_requires_valid_node_token():
    client = TestClient(create_app())
    r = client.post("/api/nodes/heartbeat", json={"status": "online"})
    assert r.status_code == 422  # missing headers
    r = client.post(
        "/api/nodes/heartbeat",
        json={"status": "online"},
        headers={
            "X-DarkPool-Node": "fake",
            "X-DarkPool-Token": "fake",
            "X-DarkPool-Timestamp": "0",
            "X-DarkPool-Signature": "00",
        },
    )
    assert r.status_code == 401


def test_api_workloads_requires_auth():
    client = TestClient(create_app())
    r = client.get("/api/workloads")
    assert r.status_code == 401


def test_admin_login_works():
    client = TestClient(create_app())
    r = client.post("/api/auth/login", json={"username": "admin", "password": "test-pass-123"})
    assert r.status_code == 200
    token = r.json()["token"]
    # Use token
    r = client.get("/api/workloads", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200


def test_admin_login_rejects_wrong_password():
    client = TestClient(create_app())
    r = client.post("/api/auth/login", json={"username": "admin", "password": "WRONG"})
    assert r.status_code == 401


def test_node_token_rotation_invalidates_old_token_after_second_rotation():
    with db_session() as db:
        node, t1 = register_node(
            db, hostname="w1", advertised_name="worker-1", public_key_pem="pub",
            capabilities={}, os_info="x", kernel="x", arch="x86_64",
            container_runtime="docker", cpu_model="x",
            cpu_total=4, ram_total_bytes=8 * 1024 ** 3, disk_total_bytes=100 * 1024 ** 3,
        )
        from darkpool_main.node_manager.manager import rotate_credentials
        t2 = rotate_credentials(db, "worker-1")
        # t1 still valid (previous_token_hash)
        assert verify_node_token(db, node.node_uuid, t1) is not None
        assert verify_node_token(db, node.node_uuid, t2) is not None
        # Third rotation -> t1 dropped
        t3 = rotate_credentials(db, "worker-1")
        assert verify_node_token(db, node.node_uuid, t1) is None  # t1 no longer valid
        assert verify_node_token(db, node.node_uuid, t2) is not None
        assert verify_node_token(db, node.node_uuid, t3) is not None
