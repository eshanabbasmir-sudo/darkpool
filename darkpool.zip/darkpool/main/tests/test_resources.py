"""Resource pool / aggregation / atomic allocation / reservation tests."""
from __future__ import annotations

import threading

from darkpool_main.database.models import Node, NodeStatus
from darkpool_main.database.session import db_session, get_engine
from darkpool_main.node_manager.manager import register_node
from darkpool_main.resource_manager.pool import (
    aggregate,
    get_capacity,
    release,
    reserve_atomic,
)


def _make_node(db, node_id: str, cpu=8, ram_gb=16, disk_gb=200):
    return register_node(
        db, hostname=node_id, advertised_name=node_id, public_key_pem="pub",
        capabilities={}, os_info="x", kernel="x", arch="x86_64",
        container_runtime="docker", cpu_model="x",
        cpu_total=cpu, ram_total_bytes=ram_gb * 1024 ** 3,
        disk_total_bytes=disk_gb * 1024 ** 3,
    )


def test_aggregate_empty():
    with db_session() as db:
        s = aggregate(db)
        assert s.cpu_total == 0
        assert s.ram_total_bytes == 0


def test_aggregate_sums_across_nodes():
    with db_session() as db:
        _make_node(db, "worker-1", cpu=8, ram_gb=16, disk_gb=200)
        _make_node(db, "worker-2", cpu=4, ram_gb=8, disk_gb=100)
        s = aggregate(db)
        assert s.cpu_total == 12
        assert s.ram_total_bytes == 24 * 1024 ** 3
        assert s.disk_total_bytes == 300 * 1024 ** 3
        assert s.cpu_available == 12
        assert s.ram_available_bytes == 24 * 1024 ** 3
        assert s.disk_available_bytes == 300 * 1024 ** 3


def test_reserve_atomic_subtracts_capacity():
    with db_session() as db:
        _make_node(db, "worker-1", cpu=8, ram_gb=16, disk_gb=200)
        ok = reserve_atomic(
            db,
            node_id="worker-1",
            workload_id="wl-1",
            cpu=2,
            ram_bytes=2 * 1024 ** 3,
            disk_bytes=20 * 1024 ** 3,
        )
        assert ok is True
        cap = get_capacity(db, "worker-1")
        # 8 - 2 (alloc) - 1 (reserve) = 5
        assert cap.cpu_available == 5
        # 16GB - 2GB (alloc) - 1GB (reserve) = 13GB
        assert cap.ram_available_bytes == 13 * 1024 ** 3
        # 200GB - 20GB (alloc) - 5GB (reserve) = 175GB
        assert cap.disk_available_bytes == 175 * 1024 ** 3


def test_reserve_atomic_rejects_insufficient_ram():
    with db_session() as db:
        _make_node(db, "worker-1", cpu=4, ram_gb=4, disk_gb=20)
        ok = reserve_atomic(
            db, node_id="worker-1", workload_id="wl-1",
            cpu=1, ram_bytes=10 * 1024 ** 3,  # 10GB > 4GB total
            disk_bytes=1 * 1024 ** 3,
        )
        assert ok is False


def test_reserve_atomic_rejects_insufficient_disk():
    with db_session() as db:
        _make_node(db, "worker-1", cpu=4, ram_gb=4, disk_gb=10)
        ok = reserve_atomic(
            db, node_id="worker-1", workload_id="wl-1",
            cpu=1, ram_bytes=1 * 1024 ** 3,
            disk_bytes=100 * 1024 ** 3,
        )
        assert ok is False


def test_release_returns_capacity():
    with db_session() as db:
        _make_node(db, "worker-1", cpu=8, ram_gb=16, disk_gb=200)
        assert reserve_atomic(db, "worker-1", "wl-1", 4, 4 * 1024 ** 3, 40 * 1024 ** 3)
        assert get_capacity(db, "worker-1").cpu_available == 3  # 8-4-1
        assert release(db, "wl-1") is True
        assert get_capacity(db, "worker-1").cpu_available == 7  # 8-1 reserve


def test_reserve_atomic_concurrent_does_not_oversubscribe():
    """Two concurrent threads must NOT both reserve the same last CPU slot."""
    with db_session() as db:
        _make_node(db, "worker-1", cpu=4, ram_gb=4, disk_gb=20)
        # Reserve enough that only ONE more 1-CPU slot is available
        reserve_atomic(db, "worker-1", "wl-pre", 2, 1 * 1024 ** 3, 5 * 1024 ** 3)
        # 4 - 2 (alloc) - 1 (reserve) = 1 slot remaining

        results = []
        lock = threading.Lock()

        def try_reserve(name):
            from sqlalchemy.orm import Session
            Session_ = db_session  # use the helper

            with Session_() as s:
                ok = reserve_atomic(
                    s, node_id="worker-1", workload_id=name,
                    cpu=1, ram_bytes=512 * 1024 ** 2, disk_bytes=1 * 1024 ** 3,
                )
                with lock:
                    results.append(ok)

        threads = [threading.Thread(target=try_reserve, args=(f"wl-{i}",)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # Exactly ONE should succeed
        assert sum(1 for r in results if r) == 1, f"expected 1 success, got {results}"
