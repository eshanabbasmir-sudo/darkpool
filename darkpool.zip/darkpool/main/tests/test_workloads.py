"""Workload lifecycle tests: creation, scheduling, stop, release."""
from __future__ import annotations

from fastapi.testclient import TestClient

from darkpool_main.app import create_app
from darkpool_main.database.models import Workload, WorkloadStatus
from darkpool_main.database.session import db_session
from darkpool_main.node_manager.manager import register_node
from darkpool_main.resource_manager.pool import get_capacity


def _seed_node(db):
    return register_node(
        db, hostname="w1", advertised_name="worker-1", public_key_pem="pub",
        capabilities={"features": ["ubuntu", "docker"]}, os_info="Ubuntu",
        kernel="5.15", arch="x86_64", container_runtime="docker",
        cpu_model="Intel", cpu_total=8, ram_total_bytes=16 * 1024 ** 3,
        disk_total_bytes=200 * 1024 ** 3,
    )


def _admin_token(client: TestClient) -> str:
    r = client.post("/api/auth/login", json={"username": "admin", "password": "test-pass-123"})
    return r.json()["token"]


def test_create_workload_schedules_on_node():
    with db_session() as db:
        _seed_node(db)
    client = TestClient(create_app())
    token = _admin_token(client)
    r = client.post(
        "/api/workloads",
        json={"image": "alpine:3.19", "cpu": 2, "ram_mb": 1024, "disk_gb": 5},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 201, r.text
    data = r.json()
    assert data["node_id"] == "worker-1"
    assert data["status"] == "scheduled"
    assert data["workspace_token"]
    # Verify reservation
    with db_session() as db:
        cap = get_capacity(db, "worker-1")
        # 8 - 2 (alloc) - 1 (reserve) = 5
        assert cap.cpu_available == 5


def test_create_workload_fails_when_no_capacity():
    with db_session() as db:
        register_node(
            db, hostname="w1", advertised_name="worker-1", public_key_pem="pub",
            capabilities={"features": []}, os_info="x", kernel="x", arch="x86_64",
            container_runtime="docker", cpu_model="x",
            cpu_total=2, ram_total_bytes=2 * 1024 ** 3, disk_total_bytes=10 * 1024 ** 3,
        )
    client = TestClient(create_app())
    token = _admin_token(client)
    r = client.post(
        "/api/workloads",
        json={"image": "alpine:3.19", "cpu": 8, "ram_mb": 4096, "disk_gb": 50},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 409


def test_stop_workload_releases_resources():
    with db_session() as db:
        _seed_node(db)
    client = TestClient(create_app())
    token = _admin_token(client)
    r = client.post(
        "/api/workloads",
        json={"image": "alpine:3.19", "cpu": 2, "ram_mb": 1024, "disk_gb": 5},
        headers={"Authorization": f"Bearer {token}"},
    )
    wl_id = r.json()["id"]
    # Stop it
    r = client.delete(f"/api/workloads/{wl_id}", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    # Capacity should be back to baseline minus reserve
    with db_session() as db:
        cap = get_capacity(db, "worker-1")
        assert cap.cpu_available == 7  # 8 - 1 reserve
