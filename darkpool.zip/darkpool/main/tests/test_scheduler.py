"""Scheduler tests: selection, insufficient resources, drain, concurrent."""
from __future__ import annotations

from darkpool_main.database.session import db_session
from darkpool_main.node_manager.manager import drain_node, register_node
from darkpool_main.scheduler.scoring import schedule, select_node


def _add_node(db, node_id, cpu=8, ram_gb=16, disk_gb=200, features=None, runtime="docker"):
    caps = {"features": features or ["ubuntu", "docker"], "container_runtime": runtime}
    return register_node(
        db, hostname=node_id, advertised_name=node_id, public_key_pem="pub",
        capabilities=caps, os_info="Ubuntu 22.04", kernel="5.15", arch="x86_64",
        container_runtime=runtime, cpu_model="Intel",
        cpu_total=cpu, ram_total_bytes=ram_gb * 1024 ** 3,
        disk_total_bytes=disk_gb * 1024 ** 3,
    )


def test_scheduler_selects_first_fit():
    """With default best-fit, scheduler should still pick a node with enough capacity."""
    with db_session() as db:
        _add_node(db, "worker-small", cpu=2, ram_gb=2, disk_gb=20)
        _add_node(db, "worker-big", cpu=16, ram_gb=32, disk_gb=500)
        node_id = schedule(
            db, workload_id="wl-1",
            cpu_req=4, ram_bytes_req=4 * 1024 ** 3, disk_bytes_req=40 * 1024 ** 3,
        )
        assert node_id is not None
        # worker-small can't fit; must be worker-big
        assert node_id == "worker-big"


def test_scheduler_returns_none_when_insufficient():
    with db_session() as db:
        _add_node(db, "worker-tiny", cpu=1, ram_gb=1, disk_gb=5)
        node_id = schedule(
            db, workload_id="wl-1",
            cpu_req=8, ram_bytes_req=8 * 1024 ** 3, disk_bytes_req=50 * 1024 ** 3,
        )
        assert node_id is None


def test_scheduler_skips_draining_nodes():
    with db_session() as db:
        _add_node(db, "worker-1", cpu=8, ram_gb=16, disk_gb=200)
        _add_node(db, "worker-2", cpu=8, ram_gb=16, disk_gb=200)
        drain_node(db, "worker-1", True)
        node_id = schedule(
            db, workload_id="wl-1",
            cpu_req=2, ram_bytes_req=2 * 1024 ** 3, disk_bytes_req=20 * 1024 ** 3,
        )
        assert node_id == "worker-2"


def test_scheduler_feature_match():
    with db_session() as db:
        _add_node(db, "worker-no-gpu", cpu=8, ram_gb=16, disk_gb=200, features=["ubuntu"])
        _add_node(db, "worker-gpu", cpu=8, ram_gb=16, disk_gb=200, features=["ubuntu", "gpu"])
        node_id = schedule(
            db, workload_id="wl-1",
            cpu_req=2, ram_bytes_req=2 * 1024 ** 3, disk_bytes_req=20 * 1024 ** 3,
            features_required=["gpu"],
        )
        assert node_id == "worker-gpu"


def test_scheduler_reserves_atomically():
    with db_session() as db:
        _add_node(db, "worker-1", cpu=2, ram_gb=4, disk_gb=20)
        # First request for 1 CPU + 1 GB RAM succeeds
        n1 = schedule(db, "wl-1", 1, 1 * 1024 ** 3, 5 * 1024 ** 3)
        assert n1 == "worker-1"
        # Second request for 2 CPU should fail (only 1 left after reserve)
        # Worker has 2 - 1 (alloc) - 1 (reserve) = 0 CPUs available
        n2 = schedule(db, "wl-2", 2, 1 * 1024 ** 3, 5 * 1024 ** 3)
        assert n2 is None
