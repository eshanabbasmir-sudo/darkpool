"""Node registration / heartbeat / offline detection / reconnection tests."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from darkpool_main.auth.node_auth import (
    mint_node_token,
    verify_node_token,
    verify_registration_token,
)
from darkpool_main.config import reload_settings
from darkpool_main.database.models import Node, NodeStatus
from darkpool_main.database.session import db_session
from darkpool_main.node_manager.manager import (
    drain_node,
    register_node,
    receive_heartbeat,
    remove_node,
    rotate_credentials,
    update_node_state_machine,
)


def test_verify_registration_token():
    assert verify_registration_token("test-registration-token") is True
    assert verify_registration_token("wrong") is False
    assert verify_registration_token("") is False


def test_register_node_creates_credentials():
    with db_session() as db:
        node, raw_token = register_node(
            db,
            hostname="w1",
            advertised_name="worker-1",
            public_key_pem="-----BEGIN PUBLIC KEY-----\nfake\n-----END PUBLIC KEY-----\n",
            capabilities={"features": ["ubuntu", "docker"]},
            os_info="Ubuntu 22.04",
            kernel="5.15",
            arch="x86_64",
            container_runtime="docker",
            cpu_model="Intel Xeon",
            cpu_total=8,
            ram_total_bytes=16 * 1024 ** 3,
            disk_total_bytes=200 * 1024 ** 3,
        )
        assert node.id == "worker-1"
        assert node.status == NodeStatus.ONLINE
        assert node.credentials is not None
        assert node.credentials.current_token_hash
        assert node.credentials.public_key.startswith("-----BEGIN")

        # Token verifies
        assert verify_node_token(db, node.node_uuid, raw_token) is not None
        # Wrong token fails
        assert verify_node_token(db, node.node_uuid, "garbage") is None
        # Wrong node id fails
        assert verify_node_token(db, "nonexistent", raw_token) is None


def test_receive_heartbeat_updates_status():
    with db_session() as db:
        node, raw_token = register_node(
            db,
            hostname="w1",
            advertised_name="worker-1",
            public_key_pem="pub",
            capabilities={},
            os_info="Ubuntu", kernel="5", arch="x86_64",
            container_runtime="docker", cpu_model="x",
            cpu_total=4, ram_total_bytes=8 * 1024 ** 3, disk_total_bytes=100 * 1024 ** 3,
        )
        node_id = node.id
        receive_heartbeat(db, node, {
            "status": "online", "cpu_usage": 23.0,
            "ram_used": 4 * 1024 ** 3, "ram_total": 8 * 1024 ** 3,
            "ram_cached": 1024, "disk_total": 100 * 1024 ** 3, "disk_free": 60 * 1024 ** 3,
            "load_avg_1": 0.5, "load_avg_5": 0.3, "load_avg_15": 0.2,
            "rx_bytes": 1000, "tx_bytes": 2000, "uptime": 3600,
        })
    # Re-query in a fresh session to confirm persistence
    with db_session() as db:
        from darkpool_main.database.models import Node
        n = db.query(Node).filter_by(id=node_id).first()
        assert n.resources is not None
        assert n.resources.cpu_usage_pct == 23.0
        assert n.resources.ram_used_bytes == 4 * 1024 ** 3


def test_offline_detection_via_state_machine():
    with db_session() as db:
        node, _ = register_node(
            db, hostname="w1", advertised_name="worker-1", public_key_pem="pub",
            capabilities={}, os_info="x", kernel="x", arch="x86_64",
            container_runtime="docker", cpu_model="x", cpu_total=4,
            ram_total_bytes=8 * 1024 ** 3, disk_total_bytes=100 * 1024 ** 3,
        )
        # Pretend last heartbeat was 20s ago -> UNSTABLE (unstable=15, offline=45)
        node.last_heartbeat_at = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(seconds=20)
        db.add(node)

        # First tick -> UNSTABLE
        changed = update_node_state_machine(db)
        assert changed == 1
        assert node.status == NodeStatus.UNSTABLE

        # Push further out -> OFFLINE
        node.last_heartbeat_at = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(seconds=120)
        db.add(node)
        changed = update_node_state_machine(db)
        assert changed == 1
        assert node.status == NodeStatus.OFFLINE


def test_drain_then_undrain():
    with db_session() as db:
        node, _ = register_node(
            db, hostname="w1", advertised_name="worker-1", public_key_pem="pub",
            capabilities={}, os_info="x", kernel="x", arch="x86_64",
            container_runtime="docker", cpu_model="x", cpu_total=4,
            ram_total_bytes=8 * 1024 ** 3, disk_total_bytes=100 * 1024 ** 3,
        )
        assert drain_node(db, "worker-1", True)
        assert node.draining is True
        assert node.status == NodeStatus.DRAINING
        assert drain_node(db, "worker-1", False)
        assert node.draining is False
        assert node.status == NodeStatus.ONLINE


def test_rotate_credentials_keeps_previous_valid():
    with db_session() as db:
        node, old_token = register_node(
            db, hostname="w1", advertised_name="worker-1", public_key_pem="pub",
            capabilities={}, os_info="x", kernel="x", arch="x86_64",
            container_runtime="docker", cpu_model="x", cpu_total=4,
            ram_total_bytes=8 * 1024 ** 3, disk_total_bytes=100 * 1024 ** 3,
        )
        new_token = rotate_credentials(db, "worker-1")
        assert new_token != old_token
        # New token works
        assert verify_node_token(db, node.node_uuid, new_token) is not None
        # Old token still valid (previous_token_hash) during rotation window
        assert verify_node_token(db, node.node_uuid, old_token) is not None
        # Garbage fails
        assert verify_node_token(db, node.node_uuid, "garbage") is None
