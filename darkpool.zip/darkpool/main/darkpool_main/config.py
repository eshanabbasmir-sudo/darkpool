"""Centralized configuration for the DarkPool Main VPS.

Loads from environment variables (see .env.example) with sane defaults
suitable for development. Production deployments must override the secrets
via environment variables or a secured .env file.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _bool(v: str | None, default: bool = False) -> bool:
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "on"}


def _int(v: str | None, default: int) -> int:
    try:
        return int(v) if v is not None else default
    except (TypeError, ValueError):
        return default


def _float(v: str | None, default: float) -> float:
    try:
        return float(v) if v is not None else default
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    # Core
    env: str = field(default_factory=lambda: os.getenv("ENV", "development"))
    secret_key: str = field(
        default_factory=lambda: os.getenv("SECRET_KEY", "dev-insecure-secret")
    )
    public_base_url: str = field(
        default_factory=lambda: os.getenv("PUBLIC_BASE_URL", "http://localhost:8000")
    )

    # Database
    database_url: str = field(
        default_factory=lambda: os.getenv("DATABASE_URL", "sqlite:///./darkpool.db")
    )

    # Admin bootstrap
    admin_username: str = field(
        default_factory=lambda: os.getenv("ADMIN_USERNAME", "admin")
    )
    admin_password: str = field(
        default_factory=lambda: os.getenv("ADMIN_PASSWORD", "")
    )
    admin_email: str = field(
        default_factory=lambda: os.getenv("ADMIN_EMAIL", "admin@example.com")
    )

    # Node registration
    node_registration_token: str = field(
        default_factory=lambda: os.getenv(
            "NODE_REGISTRATION_TOKEN", "rotate-this-token-on-first-install"
        )
    )

    # Heartbeat
    heartbeat_interval_sec: int = field(
        default_factory=lambda: _int(os.getenv("HEARTBEAT_INTERVAL_SEC"), 10)
    )
    heartbeat_grace_sec: int = field(
        default_factory=lambda: _int(os.getenv("HEARTBEAT_GRACE_SEC"), 30)
    )
    unstable_threshold_sec: int = field(
        default_factory=lambda: _int(os.getenv("UNSTABLE_THRESHOLD_SEC"), 15)
    )
    offline_threshold_sec: int = field(
        default_factory=lambda: _int(os.getenv("OFFLINE_THRESHOLD_SEC"), 45)
    )

    # Reservations
    cpu_reserve_cores: int = field(
        default_factory=lambda: _int(os.getenv("CPU_RESERVE_CORES"), 1)
    )
    ram_reserve_mb: int = field(
        default_factory=lambda: _int(os.getenv("RAM_RESERVE_MB"), 1024)
    )
    disk_reserve_gb: int = field(
        default_factory=lambda: _int(os.getenv("DISK_RESERVE_GB"), 5)
    )

    # Scheduler
    scheduler_strategy: str = field(
        default_factory=lambda: os.getenv("SCHEDULER_STRATEGY", "best-fit")
    )
    scheduler_score_weight_cpu: float = field(
        default_factory=lambda: _float(os.getenv("SCHEDULER_SCORE_WEIGHT_CPU"), 1.0)
    )
    scheduler_score_weight_ram: float = field(
        default_factory=lambda: _float(os.getenv("SCHEDULER_SCORE_WEIGHT_RAM"), 1.0)
    )
    scheduler_score_weight_disk: float = field(
        default_factory=lambda: _float(os.getenv("SCHEDULER_SCORE_WEIGHT_DISK"), 1.0)
    )
    scheduler_score_weight_load: float = field(
        default_factory=lambda: _float(os.getenv("SCHEDULER_SCORE_WEIGHT_LOAD"), 0.5)
    )

    # Overcommit (security — see SECURITY.md)
    overcommit_cpu: bool = field(
        default_factory=lambda: _bool(os.getenv("OVERCOMMIT_CPU"), False)
    )
    overcommit_ram: bool = field(
        default_factory=lambda: _bool(os.getenv("OVERCOMMIT_RAM"), False)
    )

    # Rate limits
    rate_limit_per_minute: int = field(
        default_factory=lambda: _int(os.getenv("RATE_LIMIT_PER_MINUTE"), 120)
    )
    node_rate_limit_per_minute: int = field(
        default_factory=lambda: _int(os.getenv("NODE_RATE_LIMIT_PER_MINUTE"), 600)
    )

    # Metrics retention
    metrics_retention_days: int = field(
        default_factory=lambda: _int(os.getenv("METRICS_RETENTION_DAYS"), 30)
    )

    # mTLS
    mtls_enabled: bool = field(
        default_factory=lambda: _bool(os.getenv("MTLS_ENABLED"), False)
    )
    mtls_ca_dir: str = field(default_factory=lambda: os.getenv("MTLS_CA_DIR", ""))

    @property
    def is_dev(self) -> bool:
        return self.env == "development"

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")

    @property
    def mtls_ca_path(self) -> Path | None:
        return Path(self.mtls_ca_dir) if self.mtls_ca_dir else None


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reload_settings() -> Settings:
    global _settings
    _settings = Settings()
    return _settings
