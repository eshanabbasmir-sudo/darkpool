"""Node manager: registration, heartbeat processing, health state machine.

Health state machine:
    ONLINE  --(no heartbeat for UNSTABLE_THRESHOLD_SEC)--> UNSTABLE
    UNSTABLE --(no heartbeat for OFFLINE_THRESHOLD_SEC)--> OFFLINE
    UNSTABLE --(heartbeat received)--> ONLINE
    OFFLINE --(heartbeat received + auth ok)--> ONLINE

Drain mode is orthogonal — a draining node stays ONLINE for its workloads
but is excluded from new scheduling (see resource_manager.pool).

Workloads on OFFLINE nodes are marked UNKNOWN (not destroyed). They are
recovered when the node comes back, or marked FAILED after a configurable
quarantine period (future feature).
"""
from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy.orm import Session

from darkpool_main.config import get_settings
from darkpool_main.database.models import (
    Event,
    Heartbeat,
    Node,
    NodeCredential,
    NodeResource,
    NodeStatus,
    Workload,
    WorkloadStatus,
)


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def register_node(
    db: Session,
    *,
    hostname: str | None,
    advertised_name: str | None,
    public_key_pem: str,
    capabilities: dict[str, Any],
    os_info: str | None,
    kernel: str | None,
    arch: str | None,
    container_runtime: str | None,
    cpu_model: str | None,
    cpu_total: int,
    ram_total_bytes: int,
    disk_total_bytes: int,
) -> tuple[Node, str]:
    """Register a new node. Caller MUST have already verified the registration
    token. Returns (node, raw_node_token).
    """
    settings = get_settings()
    from darkpool_main.auth.node_auth import mint_node_token

    node_uuid = f"node-{_short_uuid()}"
    node_id = advertised_name or node_uuid
    # Ensure uniqueness
    suffix = 1
    while db.query(Node).filter_by(id=node_id).first():
        node_id = f"{advertised_name or 'worker'}-{suffix}"
        suffix += 1

    node = Node(
        id=node_id,
        node_uuid=node_uuid,
        hostname=hostname,
        advertised_name=advertised_name,
        status=NodeStatus.ONLINE,
        is_main=False,
        enabled=True,
        capabilities=capabilities,
        os=os_info,
        kernel=kernel,
        arch=arch,
        container_runtime=container_runtime,
        cpu_model=cpu_model,
        cpu_total=cpu_total,
        ram_total_bytes=ram_total_bytes,
        disk_total_bytes=disk_total_bytes,
        cpu_reserve=settings.cpu_reserve_cores,
        ram_reserve_bytes=settings.ram_reserve_mb * 1024 * 1024,
        disk_reserve_bytes=settings.disk_reserve_gb * 1024 * 1024 * 1024,
        last_heartbeat_at=_now(),
        last_seen_at=_now(),
    )
    db.add(node)
    db.flush()

    cred = NodeCredential(
        node_id=node.id,
        public_key=public_key_pem,
        current_token_hash="",  # set by mint_node_token
        token_rotated_at=_now(),
        token_expires_at=_now() + timedelta(days=90),
    )
    db.add(cred)
    db.flush()

    raw = mint_node_token(db, node)
    _event(db, "node.registered", node_id=node.id, message=f"node {node.id} registered")
    return node, raw


def receive_heartbeat(
    db: Session,
    node: Node,
    payload: dict[str, Any],
) -> None:
    """Record a heartbeat and refresh node status."""
    now = _now()
    node.last_heartbeat_at = now
    node.last_seen_at = now
    if node.status == NodeStatus.OFFLINE:
        node.status = NodeStatus.ONLINE
        _event(db, "node.recovered", node_id=node.id, message=f"node {node.id} recovered")
    elif node.status == NodeStatus.UNSTABLE:
        node.status = NodeStatus.ONLINE
    db.add(node)

    # Update resource snapshot
    res = node.resources
    if res is None:
        res = NodeResource(node_id=node.id)
        db.add(res)
        db.flush()
        node.resources = res
    res.cpu_usage_pct = float(payload.get("cpu_usage", 0.0))
    res.load_avg_1 = float(payload.get("load_avg_1", 0.0))
    res.load_avg_5 = float(payload.get("load_avg_5", 0.0))
    res.load_avg_15 = float(payload.get("load_avg_15", 0.0))
    res.ram_used_bytes = int(payload.get("ram_used", 0))
    res.ram_free_bytes = max(0, int(payload.get("ram_total", 0)) - int(payload.get("ram_used", 0)))
    res.ram_cached_bytes = int(payload.get("ram_cached", 0))
    res.disk_used_bytes = int(payload.get("disk_total", 0)) - int(payload.get("disk_free", 0))
    res.disk_free_bytes = int(payload.get("disk_free", 0))
    res.filesystem = payload.get("filesystem")
    res.mount_point = payload.get("mount_point")
    res.rx_bytes = int(payload.get("rx_bytes", 0))
    res.tx_bytes = int(payload.get("tx_bytes", 0))
    res.uptime_sec = int(payload.get("uptime", 0))
    res.updated_at = now
    db.add(res)

    db.add(
        Heartbeat(
            node_id=node.id,
            cpu_usage_pct=float(payload.get("cpu_usage", 0.0)),
            ram_used_bytes=int(payload.get("ram_used", 0)),
            ram_total_bytes=int(payload.get("ram_total", 0)),
            disk_free_bytes=int(payload.get("disk_free", 0)),
            status=payload.get("status", "online"),
            timestamp=now,
        )
    )


def update_node_state_machine(db: Session) -> int:
    """Recompute node statuses based on heartbeat staleness.

    Returns the number of nodes whose status changed.
    """
    settings = get_settings()
    now = _now()
    changed = 0
    for node in db.query(Node).filter(Node.is_main.is_(False)).all():
        if node.status in (NodeStatus.DISABLED,):
            continue
        if node.last_heartbeat_at is None:
            continue
        age = (now - node.last_heartbeat_at).total_seconds()
        new_status = node.status
        if age > settings.offline_threshold_sec and node.status != NodeStatus.OFFLINE:
            new_status = NodeStatus.OFFLINE
            _event(
                db,
                "node.offline",
                node_id=node.id,
                message=f"node {node.id} marked OFFLINE (no heartbeat for {int(age)}s)",
            )
            _mark_workloads_unknown(db, node.id)
        elif age > settings.unstable_threshold_sec and node.status == NodeStatus.ONLINE:
            new_status = NodeStatus.UNSTABLE
            _event(
                db,
                "node.unstable",
                node_id=node.id,
                message=f"node {node.id} marked UNSTABLE (no heartbeat for {int(age)}s)",
            )
        if new_status != node.status:
            node.status = new_status
            db.add(node)
            changed += 1
    return changed


def _mark_workloads_unknown(db: Session, node_id: str) -> None:
    for w in (
        db.query(Workload)
        .filter_by(node_id=node_id, status=WorkloadStatus.RUNNING)
        .all()
    ):
        w.status = WorkloadStatus.UNKNOWN
        w.error_message = "node went offline; workload state uncertain"
        db.add(w)


def enable_node(db: Session, node_id: str) -> bool:
    node = db.query(Node).filter_by(id=node_id).first()
    if node is None:
        return False
    node.enabled = True
    db.add(node)
    _event(db, "node.enabled", node_id=node.id, message=f"node {node.id} enabled")
    return True


def disable_node(db: Session, node_id: str) -> bool:
    node = db.query(Node).filter_by(id=node_id).first()
    if node is None:
        return False
    node.enabled = False
    db.add(node)
    _event(db, "node.disabled", node_id=node.id, message=f"node {node.id} disabled")
    return True


def drain_node(db: Session, node_id: str, drain: bool = True) -> bool:
    node = db.query(Node).filter_by(id=node_id).first()
    if node is None:
        return False
    node.draining = drain
    if drain and node.status == NodeStatus.ONLINE:
        node.status = NodeStatus.DRAINING
    elif not drain and node.status == NodeStatus.DRAINING:
        node.status = NodeStatus.ONLINE
    db.add(node)
    _event(
        db,
        "node.drain" if drain else "node.undrain",
        node_id=node.id,
        message=f"node {node.id} drain={'on' if drain else 'off'}",
    )
    return True


def remove_node(db: Session, node_id: str) -> bool:
    node = db.query(Node).filter_by(id=node_id).first()
    if node is None:
        return False
    # Don't hard-delete: mark disabled+offline and let retention policy prune later.
    node.enabled = False
    node.status = NodeStatus.OFFLINE
    db.add(node)
    _event(db, "node.removed", node_id=node.id, message=f"node {node.id} removed")
    return True


def rotate_credentials(db: Session, node_id: str) -> str | None:
    """Generate a new token, return raw value. Old token remains valid for
    one step (previous_token_hash) for a smooth handoff window."""
    from darkpool_main.auth.node_auth import mint_node_token

    node = db.query(Node).filter_by(id=node_id).first()
    if node is None or node.credentials is None:
        return None
    _event(db, "node.token_rotated", node_id=node.id, message=f"node {node.id} token rotated")
    return mint_node_token(db, node)


def _event(db: Session, type_: str, node_id: str | None = None, message: str = "") -> None:
    db.add(Event(type=type_, node_id=node_id, message=message))


def _short_uuid() -> str:
    import uuid as _uuid
    return _uuid.uuid4().hex[:8]
