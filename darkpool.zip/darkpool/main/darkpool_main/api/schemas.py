"""Pydantic schemas for API request/response."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class NodeRegisterRequest(BaseModel):
    registration_token: str
    advertised_name: str | None = None
    hostname: str | None = None
    public_key_pem: str
    capabilities: dict[str, Any] = Field(default_factory=dict)
    os: str | None = None
    kernel: str | None = None
    arch: str | None = None
    container_runtime: str | None = None
    cpu_model: str | None = None
    cpu_total: int = 0
    ram_total_bytes: int = 0
    disk_total_bytes: int = 0


class NodeRegisterResponse(BaseModel):
    node_id: str
    node_uuid: str
    node_token: str
    heartbeat_interval_sec: int


class HeartbeatRequest(BaseModel):
    status: str = "online"
    cpu_usage: float = 0.0
    load_avg_1: float = 0.0
    load_avg_5: float = 0.0
    load_avg_15: float = 0.0
    ram_used: int = 0
    ram_total: int = 0
    ram_cached: int = 0
    ram_free: int = 0
    disk_total: int = 0
    disk_free: int = 0
    filesystem: str | None = None
    mount_point: str | None = None
    rx_bytes: int = 0
    tx_bytes: int = 0
    uptime: int = 0


class NodeSummary(BaseModel):
    id: str
    node_uuid: str
    hostname: str | None
    status: str
    enabled: bool
    draining: bool
    is_main: bool
    cpu_total: int
    ram_total_bytes: int
    disk_total_bytes: int
    cpu_reserve: int
    ram_reserve_bytes: int
    disk_reserve_bytes: int
    capabilities: dict[str, Any]
    os: str | None
    kernel: str | None
    arch: str | None
    container_runtime: str | None
    cpu_model: str | None
    last_heartbeat_at: datetime | None

    # live metrics
    cpu_usage_pct: float = 0.0
    ram_used_bytes: int = 0
    disk_free_bytes: int = 0
    load_avg_1: float = 0.0
    uptime_sec: int = 0


class WorkloadCreateRequest(BaseModel):
    image: str
    command: str | None = None
    env: dict[str, str] = Field(default_factory=dict)
    cpu: int = 1
    ram_mb: int = 512
    disk_gb: int = 1
    network: str = "bridge"
    features_required: list[str] = Field(default_factory=list)


class WorkloadResponse(BaseModel):
    id: str
    owner_id: int | None
    node_id: str | None
    image: str
    command: str | None
    env: dict[str, Any]
    cpu_limit: int
    ram_limit_bytes: int
    disk_limit_bytes: int
    status: str
    created_at: datetime
    started_at: datetime | None
    finished_at: datetime | None
    error_message: str | None
    workspace_token: str | None


class ResourceSummary(BaseModel):
    nodes_online: int
    nodes_total: int
    cpu_total: int
    cpu_allocated: int
    cpu_available: int
    ram_total_bytes: int
    ram_allocated_bytes: int
    ram_available_bytes: int
    disk_total_bytes: int
    disk_allocated_bytes: int
    disk_available_bytes: int
    overcommit_cpu: bool
    overcommit_ram: bool


class SystemStatus(BaseModel):
    main_status: str
    nodes_online: int
    nodes_total: int
    workloads_running: int
    workloads_total: int
    pool: ResourceSummary


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    token: str
    role: str
    username: str


class AgentCommand(BaseModel):
    """Commands sent from Main to agent via long-poll."""
    type: str  # 'start_workload' | 'stop_workload' | 'rotate_token' | 'ping'
    workload_id: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
