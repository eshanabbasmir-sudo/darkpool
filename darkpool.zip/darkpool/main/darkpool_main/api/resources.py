"""Resource API endpoints: aggregate pool view, per-node breakdown."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from darkpool_main.api.schemas import ResourceSummary
from darkpool_main.database.models import Node, NodeStatus
from darkpool_main.database.session import get_db
from darkpool_main.resource_manager.pool import aggregate, get_capacity

router = APIRouter(tags=["resources"])


@router.get("/api/resources", response_model=ResourceSummary)
def api_resources(db: Session = Depends(get_db)):
    s = aggregate(db)
    return ResourceSummary(
        nodes_online=s.nodes_online,
        nodes_total=s.nodes_total,
        cpu_total=s.cpu_total,
        cpu_allocated=s.cpu_allocated,
        cpu_available=s.cpu_available,
        ram_total_bytes=s.ram_total_bytes,
        ram_allocated_bytes=s.ram_allocated_bytes,
        ram_available_bytes=s.ram_available_bytes,
        disk_total_bytes=s.disk_total_bytes,
        disk_allocated_bytes=s.disk_allocated_bytes,
        disk_available_bytes=s.disk_available_bytes,
        overcommit_cpu=s.overcommit_cpu,
        overcommit_ram=s.overcommit_ram,
    )


@router.get("/api/resources/summary")
def api_resources_summary(db: Session = Depends(get_db)):
    """Human-readable summary, including the physical-vs-virtual distinction."""
    pool = aggregate(db)
    nodes = db.query(Node).filter(Node.is_main.is_(False)).all()
    physical = [
        {
            "node_id": n.id,
            "status": n.status.value if isinstance(n.status, NodeStatus) else str(n.status),
            "cpu_total": n.cpu_total,
            "ram_total_bytes": n.ram_total_bytes,
            "disk_total_bytes": n.disk_total_bytes,
            "is_main": n.is_main,
        }
        for n in nodes
    ]
    return {
        "physical": physical,
        "virtual_pool": {
            "cpu_total": pool.cpu_total,
            "cpu_allocated": pool.cpu_allocated,
            "cpu_available": pool.cpu_available,
            "ram_total_bytes": pool.ram_total_bytes,
            "ram_allocated_bytes": pool.ram_allocated_bytes,
            "ram_available_bytes": pool.ram_available_bytes,
            "disk_total_bytes": pool.disk_total_bytes,
            "disk_allocated_bytes": pool.disk_allocated_bytes,
            "disk_available_bytes": pool.disk_available_bytes,
        },
        "overcommit_cpu": pool.overcommit_cpu,
        "overcommit_ram": pool.overcommit_ram,
        "note": (
            "Virtual pool is a scheduling abstraction. RAM/CPU are NOT physically "
            "merged across kernels; each workload runs on a single node."
        ),
    }


@router.get("/api/resources/nodes/{node_id}")
def api_node_resources(node_id: str, db: Session = Depends(get_db)):
    cap = get_capacity(db, node_id)
    if cap is None:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="node not found")
    return {
        "node_id": node_id,
        "cpu_total": cap.cpu_total,
        "cpu_allocated": cap.cpu_allocated,
        "cpu_available": cap.cpu_available,
        "ram_total_bytes": cap.ram_total_bytes,
        "ram_allocated_bytes": cap.ram_allocated_bytes,
        "ram_available_bytes": cap.ram_available_bytes,
        "disk_total_bytes": cap.disk_total_bytes,
        "disk_allocated_bytes": cap.disk_allocated_bytes,
        "disk_available_bytes": cap.disk_available_bytes,
    }
