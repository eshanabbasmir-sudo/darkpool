"""FastAPI dependency for node authentication.

Verifies the X-DarkPool-* headers against the stored node credentials.
"""
from __future__ import annotations

from fastapi import Depends, Header, HTTPException, Request, status
from sqlalchemy.orm import Session

from darkpool_main.auth.node_auth import check_replay, verify_node_token, verify_signature
from darkpool_main.database.models import Node
from darkpool_main.database.session import get_db


def authenticate_node(
    request: Request,
    x_darkpool_node: str = Header(..., alias="X-DarkPool-Node"),
    x_darkpool_token: str = Header(..., alias="X-DarkPool-Token"),
    x_darkpool_timestamp: str = Header(..., alias="X-DarkPool-Timestamp"),
    x_darkpool_signature: str = Header(..., alias="X-DarkPool-Signature"),
    db: Session = Depends(get_db),
) -> Node:
    if not check_replay(x_darkpool_timestamp):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="stale or missing timestamp",
        )
    node = verify_node_token(db, x_darkpool_node, x_darkpool_token)
    if node is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="invalid node credentials",
        )
    # Verify signature over `timestamp|body` if public key present
    body = b""
    try:
        # Read body once and cache it for the route handler
        body = request._body if hasattr(request, "_body") else b""
    except Exception:
        body = b""
    message = f"{x_darkpool_timestamp}|"
    if body:
        message += body.decode("utf-8", errors="ignore")
    # Signature is optional in v1 (only enforced if a public key is stored).
    # In production, reject requests without signature once agents are upgraded.
    if node.credentials and node.credentials.public_key:
        if not verify_signature(node.credentials.public_key, message, x_darkpool_signature):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="invalid signature",
            )
    return node
