"""Admin auth endpoints: login, logout, me."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy.orm import Session

from darkpool_main.api.schemas import LoginRequest, LoginResponse
from darkpool_main.auth.admin_auth import create_session, revoke_session, verify_session
from darkpool_main.auth.audit import audit
from darkpool_main.auth.passwords import verify_password
from darkpool_main.auth.rbac import current_user
from darkpool_main.database.models import User
from darkpool_main.database.session import get_db

router = APIRouter(prefix="/api/auth", tags=["auth"])

SESSION_COOKIE = "darkpool_session"


@router.post("/login", response_model=LoginResponse)
def login(payload: LoginRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(username=payload.username, is_active=True).first()
    if user is None or not verify_password(payload.password, user.password_hash):
        audit(
            db,
            actor=f"anon:{payload.username}",
            action="login.failed",
            detail="invalid credentials",
            ip_address=request.client.host if request.client else None,
        )
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid credentials")
    session, raw = create_session(db, user, ip_address=request.client.host if request.client else None)
    response.set_cookie(
        key=SESSION_COOKIE,
        value=raw,
        httponly=True,
        secure=False,  # set True in prod behind TLS
        samesite="lax",
        max_age=12 * 3600,
    )
    audit(db, actor=f"user:{user.id}", action="login.success", ip_address=request.client.host if request.client else None)
    return LoginResponse(token=raw, role=user.role.value, username=user.username)


@router.post("/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    token = request.cookies.get(SESSION_COOKIE) or (
        request.headers.get("authorization", "").split(" ", 1)[-1].strip()
        if request.headers.get("authorization", "").lower().startswith("bearer ")
        else None
    )
    if token:
        revoke_session(db, token)
    response.delete_cookie(SESSION_COOKIE)
    return {"ok": True}


@router.get("/me")
def me(user: User = Depends(current_user)):
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "role": user.role.value,
    }
