"""Workload API: create / list / get / stop / logs.

Workload creation flow:
    1. POST /api/workloads with image + resource request
    2. Scheduler picks a node (atomic reservation)
    3. Workload row saved with status=SCHEDULED
    4. Main dispatches the start command to the chosen node's agent
       (in v1: agent polls /api/agent/{node_id}/commands; future: WebSocket)
    5. Agent starts the container and reports back status
"""
from __future__ import annotations

import secrets
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from darkpool_main.api.schemas import WorkloadCreateRequest, WorkloadResponse
from darkpool_main.auth.rbac import current_user
from darkpool_main.database.models import User, Workload, WorkloadStatus
from darkpool_main.database.session import get_db
from darkpool_main.resource_manager.pool import release
from darkpool_main.scheduler.scoring import schedule as schedule_workload

router = APIRouter(tags=["workloads"], dependencies=[Depends(current_user)])


def _workload_to_response(w: Workload) -> WorkloadResponse:
    return WorkloadResponse(
        id=w.id,
        owner_id=w.owner_id,
        node_id=w.node_id,
        image=w.image,
        command=w.command,
        env=w.env or {},
        cpu_limit=w.cpu_limit,
        ram_limit_bytes=w.ram_limit_bytes,
        disk_limit_bytes=w.disk_limit_bytes,
        status=w.status.value if isinstance(w.status, WorkloadStatus) else str(w.status),
        created_at=w.created_at,
        started_at=w.started_at,
        finished_at=w.finished_at,
        error_message=w.error_message,
        workspace_token=w.workspace_token,
    )


@router.post("/api/workloads", response_model=WorkloadResponse, status_code=201)
def create_workload(
    payload: WorkloadCreateRequest,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if payload.cpu < 1 or payload.ram_mb < 32 or payload.disk_gb < 1:
        raise HTTPException(status_code=400, detail="resource request too small")

    ram_bytes = payload.ram_mb * 1024 * 1024
    disk_bytes = payload.disk_gb * 1024 * 1024 * 1024

    # Pre-create the workload row with PENDING status so we have an ID
    wl = Workload(
        image=payload.image,
        command=payload.command,
        env=payload.env,
        cpu_limit=payload.cpu,
        ram_limit_bytes=ram_bytes,
        disk_limit_bytes=disk_bytes,
        network=payload.network,
        features_required=payload.features_required,
        status=WorkloadStatus.PENDING,
        owner_id=user.id,
        workspace_token=secrets.token_hex(16),
    )
    db.add(wl)
    db.flush()

    node_id = schedule_workload(
        db,
        workload_id=wl.id,
        cpu_req=payload.cpu,
        ram_bytes_req=ram_bytes,
        disk_bytes_req=disk_bytes,
        features_required=payload.features_required,
    )
    if node_id is None:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="no node with sufficient capacity for this request",
        )
    wl.node_id = node_id
    wl.status = WorkloadStatus.SCHEDULED
    db.add(wl)
    db.flush()
    # Note: actual container start happens when the agent polls for commands.
    return _workload_to_response(wl)


@router.get("/api/workloads", response_model=list[WorkloadResponse])
def list_workloads(
    status_filter: str | None = None,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    q = db.query(Workload)
    if user.role != "admin":
        q = q.filter_by(owner_id=user.id)
    if status_filter:
        q = q.filter(Workload.status == status_filter)
    return [_workload_to_response(w) for w in q.all()]


@router.get("/api/workloads/{workload_id}", response_model=WorkloadResponse)
def get_workload(workload_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    w = db.query(Workload).filter_by(id=workload_id).first()
    if w is None:
        raise HTTPException(status_code=404, detail="workload not found")
    if user.role != "admin" and w.owner_id != user.id:
        raise HTTPException(status_code=403, detail="forbidden")
    return _workload_to_response(w)


@router.delete("/api/workloads/{workload_id}")
def stop_workload(workload_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    w = db.query(Workload).filter_by(id=workload_id).first()
    if w is None:
        raise HTTPException(status_code=404, detail="workload not found")
    if user.role != "admin" and w.owner_id != user.id:
        raise HTTPException(status_code=403, detail="forbidden")
    if w.status not in (WorkloadStatus.STOPPED, WorkloadStatus.FAILED):
        # Mark as pending-stop; agent will pick it up and call back.
        w.status = WorkloadStatus.STOPPED
        w.finished_at = datetime.now(timezone.utc).replace(tzinfo=None)
        db.add(w)
    release(db, workload_id)
    return {"ok": True, "id": workload_id, "status": w.status.value}
