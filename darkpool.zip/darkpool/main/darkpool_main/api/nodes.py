"""Node API endpoints: register, heartbeat, list, get, delete, drain, etc.

NOTE on `register`: this is the ONLY endpoint that accepts the registration
token in the body. After registration, agents authenticate via signed
heartbeats.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from darkpool_main.api.deps import authenticate_node
from darkpool_main.api.schemas import (
    HeartbeatRequest,
    NodeRegisterRequest,
    NodeRegisterResponse,
    NodeSummary,
)
from darkpool_main.auth.audit import audit
from darkpool_main.auth.node_auth import verify_registration_token
from darkpool_main.config import get_settings
from darkpool_main.database.models import Node, NodeStatus
from darkpool_main.database.session import get_db
from darkpool_main.node_manager.manager import (
    drain_node,
    receive_heartbeat,
    register_node,
    remove_node,
    rotate_credentials,
)

router = APIRouter(tags=["nodes"])


def _node_to_summary(node: Node) -> NodeSummary:
    res = node.resources
    return NodeSummary(
        id=node.id,
        node_uuid=node.node_uuid,
        hostname=node.hostname,
        status=node.status.value if isinstance(node.status, NodeStatus) else str(node.status),
        enabled=node.enabled,
        draining=node.draining,
        is_main=node.is_main,
        cpu_total=node.cpu_total,
        ram_total_bytes=node.ram_total_bytes,
        disk_total_bytes=node.disk_total_bytes,
        cpu_reserve=node.cpu_reserve,
        ram_reserve_bytes=node.ram_reserve_bytes,
        disk_reserve_bytes=node.disk_reserve_bytes,
        capabilities=node.capabilities or {},
        os=node.os,
        kernel=node.kernel,
        arch=node.arch,
        container_runtime=node.container_runtime,
        cpu_model=node.cpu_model,
        last_heartbeat_at=node.last_heartbeat_at,
        cpu_usage_pct=res.cpu_usage_pct if res else 0.0,
        ram_used_bytes=res.ram_used_bytes if res else 0,
        disk_free_bytes=res.disk_free_bytes if res else 0,
        load_avg_1=res.load_avg_1 if res else 0.0,
        uptime_sec=res.uptime_sec if res else 0,
    )


@router.post("/api/nodes/register", response_model=NodeRegisterResponse)
def api_register(payload: NodeRegisterRequest, db: Session = Depends(get_db)):
    if not verify_registration_token(payload.registration_token):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="invalid registration token")
    node, raw_token = register_node(
        db,
        hostname=payload.hostname,
        advertised_name=payload.advertised_name,
        public_key_pem=payload.public_key_pem,
        capabilities=payload.capabilities,
        os_info=payload.os,
        kernel=payload.kernel,
        arch=payload.arch,
        container_runtime=payload.container_runtime,
        cpu_model=payload.cpu_model,
        cpu_total=payload.cpu_total,
        ram_total_bytes=payload.ram_total_bytes,
        disk_total_bytes=payload.disk_total_bytes,
    )
    audit(db, actor="anon:register", action="node.register", target_id=node.id)
    return NodeRegisterResponse(
        node_id=node.id,
        node_uuid=node.node_uuid,
        node_token=raw_token,
        heartbeat_interval_sec=get_settings().heartbeat_interval_sec,
    )


@router.post("/api/nodes/heartbeat")
def api_heartbeat(
    payload: HeartbeatRequest,
    node: Node = Depends(authenticate_node),
    db: Session = Depends(get_db),
):
    receive_heartbeat(db, node, payload.model_dump())
    return {"ok": True, "node_id": node.id, "status": node.status.value}


@router.get("/api/nodes", response_model=list[NodeSummary])
def api_list_nodes(
    status_filter: str | None = Query(None, alias="status"),
    _admin=Depends(lambda: None),  # public for v1 (no admin required to read); lock down in prod
    db: Session = Depends(get_db),
):
    q = db.query(Node)
    if status_filter:
        q = q.filter(Node.status == status_filter)
    return [_node_to_summary(n) for n in q.all()]


@router.get("/api/nodes/{node_id}", response_model=NodeSummary)
def api_get_node(node_id: str, db: Session = Depends(get_db)):
    node = db.query(Node).filter_by(id=node_id).first()
    if node is None:
        raise HTTPException(status_code=404, detail="node not found")
    return _node_to_summary(node)


@router.delete("/api/nodes/{node_id}")
def api_delete_node(node_id: str, db: Session = Depends(get_db)):
    if not remove_node(db, node_id):
        raise HTTPException(status_code=404, detail="node not found")
    return {"ok": True, "removed": node_id}


@router.post("/api/nodes/{node_id}/drain")
def api_drain(node_id: str, on: bool = True, db: Session = Depends(get_db)):
    if not drain_node(db, node_id, on):
        raise HTTPException(status_code=404, detail="node not found")
    return {"ok": True, "draining": on}


@router.post("/api/nodes/{node_id}/rotate-token")
def api_rotate_token(node_id: str, db: Session = Depends(get_db)):
    raw = rotate_credentials(db, node_id)
    if raw is None:
        raise HTTPException(status_code=404, detail="node not found")
    return {"ok": True, "node_token": raw}


@router.get("/api/nodes/{node_id}/capacity")
def api_node_capacity(node_id: str, db: Session = Depends(get_db)):
    from darkpool_main.resource_manager.pool import get_capacity
    cap = get_capacity(db, node_id)
    if cap is None:
        raise HTTPException(status_code=404, detail="node not found")
    return {
        "cpu_total": cap.cpu_total,
        "cpu_allocated": cap.cpu_allocated,
        "cpu_available": cap.cpu_available,
        "ram_total_bytes": cap.ram_total_bytes,
        "ram_allocated_bytes": cap.ram_allocated_bytes,
        "ram_available_bytes": cap.ram_available_bytes,
        "disk_total_bytes": cap.disk_total_bytes,
        "disk_allocated_bytes": cap.disk_allocated_bytes,
        "disk_available_bytes": cap.disk_available_bytes,
    }
