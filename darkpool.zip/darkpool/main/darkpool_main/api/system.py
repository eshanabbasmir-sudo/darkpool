"""System status & metrics endpoints."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from darkpool_main.api.deps import authenticate_node
from darkpool_main.api.schemas import SystemStatus
from darkpool_main.auth.rbac import current_user
from darkpool_main.database.models import (
    AuditLog,
    Event,
    Metric,
    Node,
    NodeStatus,
    Workload,
    WorkloadStatus,
)
from darkpool_main.database.session import get_db
from darkpool_main.resource_manager.pool import aggregate

router = APIRouter(tags=["system"])


@router.get("/api/system/status", response_model=SystemStatus)
def system_status(db: Session = Depends(get_db)):
    pool = aggregate(db)
    nodes_online = (
        db.query(Node)
        .filter(Node.is_main.is_(False))
        .filter(Node.status.in_([NodeStatus.ONLINE, NodeStatus.UNSTABLE]))
        .count()
    )
    nodes_total = db.query(Node).filter(Node.is_main.is_(False)).count()
    workloads_running = (
        db.query(Workload)
        .filter(Workload.status == WorkloadStatus.RUNNING)
        .count()
    )
    workloads_total = db.query(Workload).count()
    return SystemStatus(
        main_status="ONLINE",
        nodes_online=nodes_online,
        nodes_total=nodes_total,
        workloads_running=workloads_running,
        workloads_total=workloads_total,
        pool=__pool_summary(pool),
    )


def __pool_summary(pool):
    from darkpool_main.api.schemas import ResourceSummary

    return ResourceSummary(
        nodes_online=pool.nodes_online,
        nodes_total=pool.nodes_total,
        cpu_total=pool.cpu_total,
        cpu_allocated=pool.cpu_allocated,
        cpu_available=pool.cpu_available,
        ram_total_bytes=pool.ram_total_bytes,
        ram_allocated_bytes=pool.ram_allocated_bytes,
        ram_available_bytes=pool.ram_available_bytes,
        disk_total_bytes=pool.disk_total_bytes,
        disk_allocated_bytes=pool.disk_allocated_bytes,
        disk_available_bytes=pool.disk_available_bytes,
        overcommit_cpu=pool.overcommit_cpu,
        overcommit_ram=pool.overcommit_ram,
    )


@router.get("/api/metrics")
def metrics(
    name: str | None = Query(None),
    node_id: str | None = Query(None),
    hours: int = Query(24, ge=1, le=24 * 30),
    db: Session = Depends(get_db),
):
    since = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=hours)
    q = db.query(Metric).filter(Metric.timestamp >= since)
    if name:
        q = q.filter(Metric.name == name)
    if node_id:
        q = q.filter(Metric.node_id == node_id)
    rows = q.order_by(Metric.timestamp.asc()).limit(10_000).all()
    return [
        {"name": r.name, "node_id": r.node_id, "value": r.value, "timestamp": r.timestamp.isoformat()}
        for r in rows
    ]


@router.get("/api/events")
def events(
    hours: int = Query(24, ge=1, le=24 * 7),
    type_filter: str | None = None,
    db: Session = Depends(get_db),
):
    since = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=hours)
    q = db.query(Event).filter(Event.timestamp >= since)
    if type_filter:
        q = q.filter(Event.type == type_filter)
    rows = q.order_by(Event.timestamp.desc()).limit(1000).all()
    return [
        {
            "id": e.id,
            "type": e.type,
            "node_id": e.node_id,
            "workload_id": e.workload_id,
            "message": e.message,
            "timestamp": e.timestamp.isoformat(),
        }
        for e in rows
    ]


@router.get("/api/audit")
def audit_log(
    hours: int = Query(24, ge=1, le=24 * 30),
    db: Session = Depends(get_db),
):
    since = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=hours)
    rows = (
        db.query(AuditLog)
        .filter(AuditLog.timestamp >= since)
        .order_by(AuditLog.timestamp.desc())
        .limit(1000)
        .all()
    )
    return [
        {
            "id": r.id,
            "actor": r.actor,
            "action": r.action,
            "target_type": r.target_type,
            "target_id": r.target_id,
            "detail": r.detail,
            "ip_address": r.ip_address,
            "timestamp": r.timestamp.isoformat(),
        }
        for r in rows
    ]


# --- Agent-facing endpoints (long-poll commands) ---------------------------

@router.get("/api/agent/commands")
def agent_commands(
    node=Depends(authenticate_node),
    db: Session = Depends(get_db),
):
    """Agent long-poll: returns commands the agent should execute.

    v1: returns pending workloads assigned to this node and any stop requests.
    """
    pending_workloads = (
        db.query(Workload)
        .filter_by(node_id=node.id, status=WorkloadStatus.SCHEDULED)
        .all()
    )
    stop_workloads = (
        db.query(Workload)
        .filter(Workload.node_id == node.id, Workload.status == WorkloadStatus.STOPPED)
        .all()
    )
    cmds = []
    for w in pending_workloads:
        cmds.append(
            {
                "type": "start_workload",
                "workload_id": w.id,
                "image": w.image,
                "command": w.command,
                "env": w.env,
                "cpu_limit": w.cpu_limit,
                "ram_limit_bytes": w.ram_limit_bytes,
                "disk_limit_bytes": w.disk_limit_bytes,
                "network": w.network,
                "workspace_token": w.workspace_token,
                "features_required": w.features_required,
            }
        )
        w.status = WorkloadStatus.STARTING
        db.add(w)
    for w in stop_workloads:
        cmds.append({"type": "stop_workload", "workload_id": w.id, "container_id": w.container_id})
        # Agent will report back confirming stop
    return {"commands": cmds}


@router.post("/api/agent/workload/{workload_id}/status")
def agent_workload_status(
    workload_id: str,
    payload: dict,
    node=Depends(authenticate_node),
    db: Session = Depends(get_db),
):
    """Agent reports workload status back to Main."""
    w = db.query(Workload).filter_by(id=workload_id, node_id=node.id).first()
    if w is None:
        raise HTTPException(status_code=404, detail="workload not found on this node")
    new_status = payload.get("status")
    try:
        w.status = WorkloadStatus(new_status)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"invalid status: {new_status}")
    if w.status == WorkloadStatus.RUNNING and w.started_at is None:
        w.started_at = datetime.now(timezone.utc).replace(tzinfo=None)
        w.container_id = payload.get("container_id")
    if w.status in (WorkloadStatus.STOPPED, WorkloadStatus.FAILED) and w.finished_at is None:
        w.finished_at = datetime.now(timezone.utc).replace(tzinfo=None)
        w.error_message = payload.get("error")
        # Release resources for terminal states
        if w.status == WorkloadStatus.STOPPED or w.status == WorkloadStatus.FAILED:
            release(db, workload_id)
    db.add(w)
    return {"ok": True}
