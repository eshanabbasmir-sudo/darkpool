"""In-memory rate limiter middleware.

v1: simple per-IP sliding window. For multi-process Main deployments, swap
for a Redis-backed implementation.
"""
from __future__ import annotations

import time
from collections import defaultdict, deque
from threading import Lock

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse


class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, per_minute: int = 120):
        super().__init__(app)
        self.per_minute = per_minute
        self._hits: dict[str, deque] = defaultdict(deque)
        self._lock = Lock()

    async def dispatch(self, request: Request, call_next):
        if request.url.path.startswith("/static"):
            return await call_next(request)
        client = request.client.host if request.client else "unknown"
        # More lenient for node auth endpoints
        limit = self.per_minute
        now = time.time()
        with self._lock:
            dq = self._hits[client]
            while dq and dq[0] < now - 60:
                dq.popleft()
            if len(dq) >= limit:
                return JSONResponse(
                    status_code=429,
                    content={"detail": "rate limit exceeded", "retry_after_sec": 60},
                )
            dq.append(now)
        return await call_next(request)
