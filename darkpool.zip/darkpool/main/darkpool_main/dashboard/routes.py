"""Dashboard routes (server-rendered Jinja2 + HTMX)."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Form, Request, Response, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
from sqlalchemy.orm import Session

from darkpool_main.auth.admin_auth import create_session, revoke_session, verify_session
from darkpool_main.auth.passwords import verify_password
from darkpool_main.config import get_settings
from darkpool_main.database.models import (
    AuditLog,
    Event,
    Node,
    NodeStatus,
    User,
    Workload,
    WorkloadStatus,
)
from darkpool_main.database.session import get_db
from darkpool_main.node_manager.manager import (
    drain_node,
    enable_node,
    disable_node,
    remove_node,
    rotate_credentials,
)
from darkpool_main.resource_manager.pool import aggregate

_TEMPLATES_DIR = Path(__file__).parent / "templates"
router = APIRouter(tags=["dashboard"])
templates = Jinja2Templates(directory=str(_TEMPLATES_DIR))
SESSION_COOKIE = "darkpool_session"


def _current_user(request: Request, db: Session) -> User | None:
    token = request.cookies.get(SESSION_COOKIE)
    return verify_session(db, token) if token else None


@router.get("/", response_class=HTMLResponse)
def dashboard_index(request: Request, db: Session = Depends(get_db)):
    user = _current_user(request, db)
    if user is None:
        return RedirectResponse(url="/login", status_code=303)
    pool = aggregate(db)
    nodes = db.query(Node).filter(Node.is_main.is_(False)).all()
    workloads = db.query(Workload).order_by(Workload.created_at.desc()).limit(20).all()
    events = db.query(Event).order_by(Event.timestamp.desc()).limit(50).all()
    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "user": user,
            "pool": pool,
            "nodes": nodes,
            "workloads": workloads,
            "events": events,
            "fmt_bytes": _fmt_bytes,
            "NodeStatus": NodeStatus,
        },
    )


@router.get("/login", response_class=HTMLResponse)
def login_form(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None})


@router.post("/login")
def login_submit(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    user = db.query(User).filter_by(username=username, is_active=True).first()
    if user is None or not verify_password(password, user.password_hash):
        return templates.TemplateResponse(
            "login.html", {"request": request, "error": "Invalid credentials"}, status_code=401
        )
    session, raw = create_session(db, user, ip_address=request.client.host if request.client else None)
    resp = RedirectResponse(url="/", status_code=303)
    resp.set_cookie(
        key=SESSION_COOKIE, value=raw, httponly=True, samesite="lax", max_age=12 * 3600
    )
    return resp


@router.get("/logout")
def logout(request: Request, db: Session = Depends(get_db)):
    token = request.cookies.get(SESSION_COOKIE)
    if token:
        revoke_session(db, token)
    resp = RedirectResponse(url="/login", status_code=303)
    resp.delete_cookie(SESSION_COOKIE)
    return resp


@router.get("/nodes/{node_id}/drain")
def dashboard_drain(node_id: str, db: Session = Depends(get_db)):
    drain_node(db, node_id, True)
    return RedirectResponse(url="/", status_code=303)


@router.get("/nodes/{node_id}/undrain")
def dashboard_undrain(node_id: str, db: Session = Depends(get_db)):
    drain_node(db, node_id, False)
    return RedirectResponse(url="/", status_code=303)


@router.get("/nodes/{node_id}/enable")
def dashboard_enable(node_id: str, db: Session = Depends(get_db)):
    enable_node(db, node_id)
    return RedirectResponse(url="/", status_code=303)


@router.get("/nodes/{node_id}/disable")
def dashboard_disable(node_id: str, db: Session = Depends(get_db)):
    disable_node(db, node_id)
    return RedirectResponse(url="/", status_code=303)


@router.get("/nodes/{node_id}/remove")
def dashboard_remove(node_id: str, db: Session = Depends(get_db)):
    remove_node(db, node_id)
    return RedirectResponse(url="/", status_code=303)


@router.get("/nodes/{node_id}/rotate")
def dashboard_rotate(node_id: str, db: Session = Depends(get_db)):
    raw = rotate_credentials(db, node_id)
    if raw is None:
        raise HTTPException(404)
    return HTMLResponse(
        f"<div class='alert'>New token for {node_id} (shown once): <code>{raw}</code></div>"
    )


@router.get("/workloads/{workload_id}/stop")
def dashboard_stop_workload(workload_id: str, db: Session = Depends(get_db)):
    w = db.query(Workload).filter_by(id=workload_id).first()
    if w is not None and w.status not in (WorkloadStatus.STOPPED, WorkloadStatus.FAILED):
        w.status = WorkloadStatus.STOPPED
        db.add(w)
    return RedirectResponse(url="/", status_code=303)


def _fmt_bytes(n: int) -> str:
    if n is None:
        return "—"
    for unit in ["B", "KiB", "MiB", "GiB", "TiB", "PiB"]:
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} EiB"
