// Auto-refresh dashboard every 15s. Charts left for future enhancement.
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => location.reload(), 15000);
});
