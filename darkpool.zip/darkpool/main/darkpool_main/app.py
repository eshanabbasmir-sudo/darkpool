"""FastAPI application factory + middleware + lifespan."""
from __future__ import annotations

import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path

_STATIC_DIR = Path(__file__).parent / "dashboard" / "static"
_TEMPLATES_DIR = Path(__file__).parent / "dashboard" / "templates"

from darkpool_main.api import auth as auth_api
from darkpool_main.api import nodes as nodes_api
from darkpool_main.api import resources as resources_api
from darkpool_main.api import system as system_api
from darkpool_main.api import workloads as workloads_api
from darkpool_main.config import get_settings
from darkpool_main.dashboard.routes import router as dashboard_router
from darkpool_main.database.migrations import init_db
from darkpool_main.scheduler.tasks import start_scheduler, stop_scheduler
from darkpool_main.utils.rate_limit import RateLimitMiddleware


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    sched = start_scheduler()
    try:
        yield
    finally:
        stop_scheduler()


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="DarkPool Main",
        description="Distributed VPS Resource Pool — Main controller",
        version="1.0.0",
        lifespan=lifespan,
    )

    # CORS (tighten in production)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"] if settings.is_dev else [],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Rate limiting
    app.add_middleware(RateLimitMiddleware, per_minute=settings.rate_limit_per_minute)

    # Request logging + audit-friendly timing
    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        start = time.time()
        response = await call_next(request)
        elapsed = (time.time() - start) * 1000
        # Skip static assets
        if not request.url.path.startswith("/static"):
            print(f"[{request.method}] {request.url.path} {response.status_code} {elapsed:.0f}ms")
        return response

    # Static + routes
    app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")
    app.include_router(auth_api.router)
    app.include_router(nodes_api.router)
    app.include_router(resources_api.router)
    app.include_router(workloads_api.router)
    app.include_router(system_api.router)
    app.include_router(dashboard_router)

    @app.get("/health")
    def health():
        return {"status": "ok", "service": "darkpool-main", "version": "1.0.0"}

    return app


app = create_app()
