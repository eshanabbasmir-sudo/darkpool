"""Password hashing using PBKDF2-HMAC-SHA256 (no external dependency).

We avoid bcrypt/argon2 here to keep the dependency footprint minimal for the
v1 spec. The hash format is `pbkdf2_sha256$iterations$salt_hex$hash_hex`
which is compatible with passlib's pbkdf2_sha256 scheme if you choose to
migrate later.
"""
from __future__ import annotations

import hashlib
import hmac
import secrets

ITERATIONS = 200_000
ALGO = "pbkdf2_sha256"


def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), ITERATIONS)
    return f"{ALGO}${ITERATIONS}${salt}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algo, iter_str, salt_hex, hash_hex = encoded.split("$")
        if algo != ALGO:
            return False
        iterations = int(iter_str)
        expected = bytes.fromhex(hash_hex)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), iterations)
        return hmac.compare_digest(expected, actual)
    except (ValueError, AttributeError):
        return False
