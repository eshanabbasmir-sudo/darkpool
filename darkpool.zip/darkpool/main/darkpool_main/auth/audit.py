"""Audit logging helper. Single point of truth for security-relevant events."""
from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from darkpool_main.database.models import AuditLog


def audit(
    db: Session,
    actor: str,
    action: str,
    target_type: str | None = None,
    target_id: str | None = None,
    detail: str | None = None,
    ip_address: str | None = None,
) -> None:
    db.add(
        AuditLog(
            actor=actor,
            action=action,
            target_type=target_type,
            target_id=target_id,
            detail=detail,
            ip_address=ip_address,
        )
    )
