"""Node authentication: registration tokens, ed25519 key exchange, rotating node tokens.

Registration flow:
    1. Admin generates a registration token (single-use) via CLI/dashboard
       and gives it to a supporter operator.
    2. Agent generates an ed25519 keypair locally (NEVER sent to Main in plaintext).
    3. Agent POSTs /api/nodes/register with:
         { registration_token, public_key_pem, advertised_name, capabilities }
    4. Main verifies the registration token, creates a Node row, mints a
       node_token (random 32 bytes, hex), stores its SHA-256 hash in
       NodeCredential.current_token_hash.
    5. Main returns the node_id + node_token (this is the ONLY time the raw
       token is visible).

Heartbeat/agent-call auth:
    Each agent request carries:
        X-DarkPool-Node: <node_id>
        X-DarkPool-Token: <current_token>
        X-DarkPool-Timestamp: <unix ts>
        X-DarkPool-Signature: <ed25519 signature of `ts|body`>
    Main verifies the timestamp is within ±60s (replay protection), the token
    matches the current hash, and the signature verifies against the stored
    public key.
"""
from __future__ import annotations

import hashlib
import secrets
import time
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from darkpool_main.config import get_settings
from darkpool_main.database.models import Node, NodeCredential

REPLAY_WINDOW_SEC = 60
TOKEN_TTL_DAYS = 90


def _hash_token(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


def issue_registration_token() -> str:
    """Issue a single-use registration token. The token is short-lived and
    verified by exact-match against settings.NODE_REGISTRATION_TOKEN.

    For multi-tenant scenarios later, store a separate DB table of pending
    registration tickets.
    """
    return secrets.token_urlsafe(32)


def verify_registration_token(token: str) -> bool:
    expected = get_settings().node_registration_token
    if not expected:
        return False
    return secrets.compare_digest(token, expected)


def mint_node_token(db: Session, node: Node) -> str:
    """Generate a fresh token, store its hash, return the raw value once."""
    raw = secrets.token_hex(32)
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    if node.credentials is None:
        cred = NodeCredential(
            node_id=node.id,
            current_token_hash=_hash_token(raw),
            token_rotated_at=now,
            token_expires_at=now + timedelta(days=TOKEN_TTL_DAYS),
        )
        db.add(cred)
    else:
        node.credentials.previous_token_hash = node.credentials.current_token_hash
        node.credentials.current_token_hash = _hash_token(raw)
        node.credentials.token_rotated_at = now
        node.credentials.token_expires_at = now + timedelta(days=TOKEN_TTL_DAYS)
    db.flush()
    return raw


def verify_node_token(db: Session, node_id: str, token: str) -> Node | None:
    if not node_id or not token:
        return None
    node = db.query(Node).filter_by(node_uuid=node_id).first()
    if node is None or node.credentials is None:
        return None
    cred = node.credentials
    if secrets.compare_digest(cred.current_token_hash, _hash_token(token)):
        return node
    # Allow previous-token rollback during rotation window
    if cred.previous_token_hash and secrets.compare_digest(
        cred.previous_token_hash, _hash_token(token)
    ):
        return node
    return None


def check_replay(timestamp_str: str) -> bool:
    try:
        ts = int(timestamp_str)
    except (TypeError, ValueError):
        return False
    return abs(int(time.time()) - ts) <= REPLAY_WINDOW_SEC


def verify_signature(public_key_pem: str, message: str, signature_hex: str) -> bool:
    """Verify an ed25519 signature. Uses cryptography library."""
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature

        pub = serialization.load_pem_public_key(public_key_pem.encode())
        if not isinstance(pub, Ed25519PublicKey):
            return False
        try:
            pub.verify(bytes.fromhex(signature_hex), message.encode())
            return True
        except (ValueError, InvalidSignature):
            return False
    except Exception:
        return False
