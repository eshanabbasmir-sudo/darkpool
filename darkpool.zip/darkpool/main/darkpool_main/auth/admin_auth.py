"""Admin session token issuance & verification.

Sessions are DB-backed so we can revoke them server-side and audit access.
A token is a 32-byte URL-safe random string; we store its SHA-256 hash so a
DB leak does not yield live tokens.
"""
from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from darkpool_main.config import get_settings
from darkpool_main.database.models import AdminSession, User

SESSION_TTL_HOURS = 12


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_session(db: Session, user: User, ip_address: str | None = None) -> tuple[AdminSession, str]:
    raw = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    session = AdminSession(
        user_id=user.id,
        token_hash=_hash_token(raw),
        created_at=now,
        expires_at=now + timedelta(hours=SESSION_TTL_HOURS),
        last_seen_at=now,
        ip_address=ip_address,
    )
    db.add(session)
    db.flush()
    return session, raw


def verify_session(db: Session, token: str) -> User | None:
    if not token:
        return None
    session = db.query(AdminSession).filter_by(token_hash=_hash_token(token)).first()
    if session is None:
        return None
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    if session.expires_at < now:
        return None
    session.last_seen_at = now
    db.add(session)
    return db.query(User).filter_by(id=session.user_id).first()


def revoke_session(db: Session, token: str) -> bool:
    session = db.query(AdminSession).filter_by(token_hash=_hash_token(token)).first()
    if session is None:
        return False
    db.delete(session)
    return True


def revoke_all_user_sessions(db: Session, user_id: int) -> int:
    sessions = db.query(AdminSession).filter_by(user_id=user_id).all()
    count = len(sessions)
    for s in sessions:
        db.delete(s)
    return count
