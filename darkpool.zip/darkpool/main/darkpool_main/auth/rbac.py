"""Role-Based Access Control.

v1 ships with two roles: admin (full dashboard/API access) and user (limited
user-facing endpoints only). The decorator below can be applied to FastAPI
routes to require a specific role.
"""
from __future__ import annotations

from fastapi import Depends, HTTPException, Request, status

from darkpool_main.auth.admin_auth import verify_session
from darkpool_main.database.models import User, UserRole
from darkpool_main.database.session import get_db


def _extract_token(request: Request) -> str | None:
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth.split(None, 1)[1].strip()
    return request.cookies.get("darkpool_session")


def current_user(
    request: Request, db=Depends(get_db)
) -> User:
    token = _extract_token(request)
    user = verify_session(db, token) if token else None
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


def require_role(*roles: UserRole):
    """FastAPI dependency factory — raises 403 if user role not in `roles`."""

    def _checker(user: User = Depends(current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient role",
            )
        return user

    return _checker


require_admin = require_role(UserRole.ADMIN)
require_user = require_role(UserRole.USER, UserRole.ADMIN)
