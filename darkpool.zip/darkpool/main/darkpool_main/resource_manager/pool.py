"""Resource pool abstraction.

CRITICAL INVARIANTS:

1. Aggregation is a SCHEDULING abstraction. We NEVER claim to have physically
   merged RAM/CPU across kernels. The dashboard explicitly labels the totals
   as "virtual pool".
2. Allocations are ATOMIC. `reserve_atomic()` acquires a per-node row lock
   (SELECT ... FOR UPDATE on Postgres; BEGIN IMMEDIATE on SQLite), re-reads
   available capacity, and commits only if enough free capacity exists.
3. Overcommit is DISABLED by default. If OVERCOMMIT_RAM=true, allocations may
   exceed physical RAM (clearly displayed). CPU overcommit is similar.
4. Each node keeps a safety reserve (CPU_RESERVE_CORES, RAM_RESERVE_MB,
   DISK_RESERVE_GB) that is never allocated.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from darkpool_main.config import get_settings
from darkpool_main.database.models import (
    Node,
    NodeResource,
    NodeStatus,
    ResourceAllocation,
    Workload,
    WorkloadStatus,
)


# Cross-process lock for SQLite (FOR UPDATE not honored). On Postgres, rely
# on row-level locking instead. The mutex is process-local; for multi-process
# Main deployments use Postgres.
_SQLITE_MUTEX = threading.RLock()


@dataclass
class NodeCapacity:
    node_id: str
    cpu_total: int
    ram_total_bytes: int
    disk_total_bytes: int
    cpu_allocated: int
    ram_allocated_bytes: int
    disk_allocated_bytes: int
    cpu_reserve: int
    ram_reserve_bytes: int
    disk_reserve_bytes: int

    @property
    def cpu_available(self) -> int:
        return max(0, self.cpu_total - self.cpu_allocated - self.cpu_reserve)

    @property
    def ram_available_bytes(self) -> int:
        return max(0, self.ram_total_bytes - self.ram_allocated_bytes - self.ram_reserve_bytes)

    @property
    def disk_available_bytes(self) -> int:
        return max(0, self.disk_total_bytes - self.disk_allocated_bytes - self.disk_reserve_bytes)


def _capacity_for(db: Session, node: Node) -> NodeCapacity:
    alloc = (
        db.query(ResourceAllocation)
        .filter_by(node_id=node.id, released_at=None)
        .all()
    )
    cpu_alloc = sum(a.cpu_cores for a in alloc)
    ram_alloc = sum(a.ram_bytes for a in alloc)
    disk_alloc = sum(a.disk_bytes for a in alloc)
    return NodeCapacity(
        node_id=node.id,
        cpu_total=node.cpu_total or 0,
        ram_total_bytes=node.ram_total_bytes or 0,
        disk_total_bytes=node.disk_total_bytes or 0,
        cpu_allocated=cpu_alloc,
        ram_allocated_bytes=ram_alloc,
        disk_allocated_bytes=disk_alloc,
        cpu_reserve=node.cpu_reserve,
        ram_reserve_bytes=node.ram_reserve_bytes,
        disk_reserve_bytes=node.disk_reserve_bytes,
    )


@dataclass
class PoolSummary:
    nodes_online: int
    nodes_total: int
    cpu_total: int
    cpu_allocated: int
    cpu_available: int
    ram_total_bytes: int
    ram_allocated_bytes: int
    ram_available_bytes: int
    disk_total_bytes: int
    disk_allocated_bytes: int
    disk_available_bytes: int
    overcommit_cpu: bool
    overcommit_ram: bool


def _node_is_schedulable(node: Node) -> bool:
    return (
        node.enabled
        and not node.draining
        and node.status in (NodeStatus.ONLINE, NodeStatus.UNSTABLE)
        and not node.is_main
    )


def list_schedulable_nodes(db: Session) -> list[Node]:
    return [n for n in db.query(Node).all() if _node_is_schedulable(n)]


def get_capacity(db: Session, node_id: str) -> NodeCapacity | None:
    node = db.query(Node).filter_by(id=node_id).first()
    if node is None:
        return None
    return _capacity_for(db, node)


def aggregate(db: Session) -> PoolSummary:
    """Aggregate all online worker nodes (NOT the Main self-node) into a
    single virtual pool view.

    NOTE: This is a scheduling/reporting abstraction only. RAM from worker A
    is NOT physically accessible to workloads on worker B.
    """
    settings = get_settings()
    nodes = db.query(Node).filter(Node.is_main.is_(False), Node.enabled.is_(True)).all()
    online = [n for n in nodes if n.status in (NodeStatus.ONLINE, NodeStatus.UNSTABLE)]

    cpu_total = sum(n.cpu_total or 0 for n in online)
    ram_total = sum(n.ram_total_bytes or 0 for n in online)
    disk_total = sum(n.disk_total_bytes or 0 for n in online)

    cpu_alloc = ram_alloc = disk_alloc = 0
    for n in online:
        cap = _capacity_for(db, n)
        cpu_alloc += cap.cpu_allocated
        ram_alloc += cap.ram_allocated_bytes
        disk_alloc += cap.disk_allocated_bytes

    return PoolSummary(
        nodes_online=len(online),
        nodes_total=len(nodes),
        cpu_total=cpu_total,
        cpu_allocated=cpu_alloc,
        cpu_available=max(0, cpu_total - cpu_alloc),
        ram_total_bytes=ram_total,
        ram_allocated_bytes=ram_alloc,
        ram_available_bytes=max(0, ram_total - ram_alloc),
        disk_total_bytes=disk_total,
        disk_allocated_bytes=disk_alloc,
        disk_available_bytes=max(0, disk_total - disk_alloc),
        overcommit_cpu=settings.overcommit_cpu,
        overcommit_ram=settings.overcommit_ram,
    )


def reserve_atomic(
    db: Session,
    node_id: str,
    workload_id: str,
    cpu: int,
    ram_bytes: int,
    disk_bytes: int,
) -> bool:
    """Atomically reserve resources on a node for a workload.

    Returns True on success, False if insufficient capacity.

    Implementation:
    - On Postgres: rely on `SELECT ... FOR UPDATE` on the node row.
    - On SQLite: hold a process-wide mutex (BEGIN IMMEDIATE).
    """
    settings = get_settings()
    with _SQLITE_MUTEX if settings.is_sqlite else _nullcontext():
        node = db.query(Node).filter_by(id=node_id).with_for_update().first()
        if node is None or not _node_is_schedulable(node):
            return False
        cap = _capacity_for(db, node)
        if not settings.overcommit_cpu and cpu > cap.cpu_available:
            return False
        if not settings.overcommit_ram and ram_bytes > cap.ram_available_bytes:
            return False
        if disk_bytes > cap.disk_available_bytes:
            return False
        db.add(
            ResourceAllocation(
                workload_id=workload_id,
                node_id=node_id,
                cpu_cores=cpu,
                ram_bytes=ram_bytes,
                disk_bytes=disk_bytes,
            )
        )
        db.flush()
        return True


def release(db: Session, workload_id: str) -> bool:
    """Release the allocation held by a workload. Returns True if released."""
    rows = (
        db.query(ResourceAllocation)
        .filter_by(workload_id=workload_id, released_at=None)
        .all()
    )
    if not rows:
        return False
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    for r in rows:
        r.released_at = now
    db.flush()
    return True


# Minimal nullcontext (Python 3.7+ has contextlib.nullcontext but be safe)
class _nullcontext:
    def __enter__(self):
        return None

    def __exit__(self, *_):
        return False
