"""Schema initialization and migration helpers.

For v1 we use SQLAlchemy `Base.metadata.create_all()`. For future versions,
switch to Alembic migrations. The bootstrap function here also seeds an admin
user if none exists.
"""
from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from darkpool_main.auth.passwords import hash_password
from darkpool_main.config import get_settings
from darkpool_main.database.models import (
    AdminSession,
    Base,
    Node,
    NodeCredential,
    User,
    UserRole,
)
from darkpool_main.database.session import db_session, get_engine


def init_db() -> None:
    """Create all tables if they don't exist."""
    Base.metadata.create_all(get_engine())
    _bootstrap_admin()


def _bootstrap_admin() -> None:
    """Create the initial admin user from env vars if no admins exist yet."""
    settings = get_settings()
    if not settings.admin_password:
        return  # explicit opt-out
    with db_session() as db:
        existing = db.query(User).filter_by(role=UserRole.ADMIN).first()
        if existing is not None:
            return
        admin = User(
            username=settings.admin_username,
            email=settings.admin_email,
            password_hash=hash_password(settings.admin_password),
            role=UserRole.ADMIN,
            is_active=True,
        )
        db.add(admin)
        db.flush()
        # Generate the initial node-registration-friendly "main" self-node
        # (only used for virtual-pool display, never scheduled against)
        main_node = Node(
            id="main",
            node_uuid="main",
            hostname="main",
            advertised_name="main",
            is_main=True,
            status=__import__("darkpool_main.database.models", fromlist=["NodeStatus"]).NodeStatus.ONLINE,
            enabled=True,
            cpu_total=0,
            ram_total_bytes=0,
            disk_total_bytes=0,
        )
        db.add(main_node)
