"""SQLAlchemy ORM models.

Schema (v1):

    users              — admin & regular users (password hashed)
    sessions           — admin dashboard sessions
    nodes              — registered supporter nodes (or main-as-node)
    node_credentials   — per-node ed25519 public key + rotating token
    node_resources     — latest reported per-node resource snapshot
    heartbeats         — historical heartbeat log (time-series)
    workloads          — scheduled container workloads
    resource_allocations — atomic allocation records per workload per node
    events             — system events (node.registered, workload.assigned, etc.)
    audit_logs         — admin/API actions requiring accountability
    metrics            — historical numeric metrics for charts

Concurrency: resource allocations are guarded by per-node row-level
`available_*` columns updated inside a transaction with SELECT ... FOR UPDATE
(emulated on SQLite via a high-level lock). See resource_manager.pool.
"""
from __future__ import annotations

import enum
import time
import uuid
from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    Column,
    DateTime,
    Enum as SAEnum,
    Float,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


def _uuid() -> str:
    return uuid.uuid4().hex


def _now() -> datetime:
    return datetime.utcnow()


# --- Enums ------------------------------------------------------------------

class NodeStatus(str, enum.Enum):
    ONLINE = "online"
    UNSTABLE = "unstable"
    OFFLINE = "offline"
    DRAINING = "draining"
    DISABLED = "disabled"


class WorkloadStatus(str, enum.Enum):
    PENDING = "pending"
    SCHEDULED = "scheduled"
    STARTING = "starting"
    RUNNING = "running"
    STOPPED = "stopped"
    FAILED = "failed"
    UNKNOWN = "unknown"  # node went offline while running


class UserRole(str, enum.Enum):
    ADMIN = "admin"
    USER = "user"


# --- Models -----------------------------------------------------------------

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(SAEnum(UserRole), default=UserRole.USER, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)

    sessions = relationship("AdminSession", back_populates="user", cascade="all, delete-orphan")


class AdminSession(Base):
    __tablename__ = "admin_sessions"

    id = Column(String(64), primary_key=True, default=_uuid)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    token_hash = Column(String(255), unique=True, nullable=False, index=True)
    created_at = Column(DateTime, default=_now, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    last_seen_at = Column(DateTime, default=_now, nullable=False)
    ip_address = Column(String(64), nullable=True)

    user = relationship("User", back_populates="sessions")


class Node(Base):
    __tablename__ = "nodes"

    id = Column(String(64), primary_key=True, default=_uuid)  # human-friendly alias assigned by Main
    node_uuid = Column(String(64), unique=True, nullable=False, index=True)  # internal UUID
    hostname = Column(String(255), nullable=True)
    advertised_name = Column(String(64), nullable=True)
    status = Column(SAEnum(NodeStatus), default=NodeStatus.OFFLINE, nullable=False, index=True)
    is_main = Column(Boolean, default=False, nullable=False)
    enabled = Column(Boolean, default=True, nullable=False)
    capabilities = Column(JSON, default=dict, nullable=False)
    os = Column(String(128), nullable=True)
    kernel = Column(String(128), nullable=True)
    arch = Column(String(32), nullable=True)
    container_runtime = Column(String(64), nullable=True)
    cpu_model = Column(String(255), nullable=True)
    cpu_total = Column(Integer, default=0, nullable=False)
    ram_total_bytes = Column(BigInteger, default=0, nullable=False)
    disk_total_bytes = Column(BigInteger, default=0, nullable=False)
    cpu_reserve = Column(Integer, default=1, nullable=False)
    ram_reserve_bytes = Column(BigInteger, default=1073741824, nullable=False)
    disk_reserve_bytes = Column(BigInteger, default=5368709120, nullable=False)
    registered_at = Column(DateTime, default=_now, nullable=False)
    last_heartbeat_at = Column(DateTime, nullable=True)
    last_seen_at = Column(DateTime, nullable=True)
    draining = Column(Boolean, default=False, nullable=False)

    credentials = relationship(
        "NodeCredential", back_populates="node", cascade="all, delete-orphan", uselist=False
    )
    resources = relationship(
        "NodeResource", back_populates="node", cascade="all, delete-orphan", uselist=False
    )
    workloads = relationship("Workload", back_populates="node")


class NodeCredential(Base):
    __tablename__ = "node_credentials"

    node_id = Column(String(64), ForeignKey("nodes.id", ondelete="CASCADE"), primary_key=True)
    public_key = Column(Text, nullable=False)  # ed25519 PEM (signed challenge response)
    current_token_hash = Column(String(255), nullable=False, index=True)  # sha256 of rotating token
    previous_token_hash = Column(String(255), nullable=True)  # allow one-step rollback
    token_rotated_at = Column(DateTime, default=_now, nullable=False)
    token_expires_at = Column(DateTime, nullable=True)

    node = relationship("Node", back_populates="credentials")


class NodeResource(Base):
    """Latest measured resource snapshot per node. Reported by agent, NOT trusted
    from API clients directly. See agent.resources.measure()."""
    __tablename__ = "node_resources"

    node_id = Column(String(64), ForeignKey("nodes.id", ondelete="CASCADE"), primary_key=True)
    cpu_usage_pct = Column(Float, default=0.0, nullable=False)
    load_avg_1 = Column(Float, default=0.0, nullable=False)
    load_avg_5 = Column(Float, default=0.0, nullable=False)
    load_avg_15 = Column(Float, default=0.0, nullable=False)
    ram_used_bytes = Column(BigInteger, default=0, nullable=False)
    ram_cached_bytes = Column(BigInteger, default=0, nullable=False)
    ram_free_bytes = Column(BigInteger, default=0, nullable=False)
    disk_used_bytes = Column(BigInteger, default=0, nullable=False)
    disk_free_bytes = Column(BigInteger, default=0, nullable=False)
    filesystem = Column(String(64), nullable=True)
    mount_point = Column(String(255), nullable=True)
    rx_bytes = Column(BigInteger, default=0, nullable=False)
    tx_bytes = Column(BigInteger, default=0, nullable=False)
    uptime_sec = Column(BigInteger, default=0, nullable=False)
    updated_at = Column(DateTime, default=_now, onupdate=_now, nullable=False)

    node = relationship("Node", back_populates="resources")


class Heartbeat(Base):
    __tablename__ = "heartbeats"

    id = Column(Integer, primary_key=True, autoincrement=True)
    node_id = Column(String(64), ForeignKey("nodes.id", ondelete="CASCADE"), nullable=False, index=True)
    cpu_usage_pct = Column(Float, default=0.0, nullable=False)
    ram_used_bytes = Column(BigInteger, default=0, nullable=False)
    ram_total_bytes = Column(BigInteger, default=0, nullable=False)
    disk_free_bytes = Column(BigInteger, default=0, nullable=False)
    status = Column(String(32), nullable=False)
    timestamp = Column(DateTime, default=_now, nullable=False, index=True)


class Workload(Base):
    __tablename__ = "workloads"

    id = Column(String(64), primary_key=True, default=_uuid)
    owner_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    node_id = Column(String(64), ForeignKey("nodes.id", ondelete="SET NULL"), nullable=True, index=True)
    image = Column(String(255), nullable=False)
    command = Column(Text, nullable=True)
    env = Column(JSON, default=dict, nullable=False)
    cpu_limit = Column(Integer, nullable=False)  # cores
    ram_limit_bytes = Column(BigInteger, nullable=False)
    disk_limit_bytes = Column(BigInteger, nullable=False)
    network = Column(String(64), default="bridge", nullable=False)
    features_required = Column(JSON, default=list, nullable=False)
    container_id = Column(String(128), nullable=True)
    status = Column(SAEnum(WorkloadStatus), default=WorkloadStatus.PENDING, nullable=False, index=True)
    created_at = Column(DateTime, default=_now, nullable=False)
    started_at = Column(DateTime, nullable=True)
    finished_at = Column(DateTime, nullable=True)
    error_message = Column(Text, nullable=True)
    workspace_token = Column(String(64), nullable=True)  # token for darkpool-info inside container

    node = relationship("Node", back_populates="workloads")


class ResourceAllocation(Base):
    """Records the resources reserved for a single workload on a single node.
    Allocation is atomic — see resource_manager.pool.reserve_atomic()."""
    __tablename__ = "resource_allocations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    workload_id = Column(String(64), ForeignKey("workloads.id", ondelete="CASCADE"), nullable=False, index=True)
    node_id = Column(String(64), ForeignKey("nodes.id", ondelete="CASCADE"), nullable=False, index=True)
    cpu_cores = Column(Integer, nullable=False)
    ram_bytes = Column(BigInteger, nullable=False)
    disk_bytes = Column(BigInteger, nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)
    released_at = Column(DateTime, nullable=True)

    __table_args__ = (UniqueConstraint("workload_id", name="uq_allocation_per_workload"),)


class Event(Base):
    """System events: node.registered, workload.assigned, etc."""
    __tablename__ = "events"

    id = Column(Integer, primary_key=True, autoincrement=True)
    type = Column(String(64), nullable=False, index=True)
    node_id = Column(String(64), nullable=True, index=True)
    workload_id = Column(String(64), nullable=True, index=True)
    message = Column(Text, nullable=False)
    data = Column(JSON, nullable=True)
    timestamp = Column(DateTime, default=_now, nullable=False, index=True)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    actor = Column(String(128), nullable=False)  # 'admin:1' / 'node:worker-01' / 'system'
    action = Column(String(128), nullable=False, index=True)
    target_type = Column(String(64), nullable=True)
    target_id = Column(String(64), nullable=True)
    detail = Column(Text, nullable=True)
    ip_address = Column(String(64), nullable=True)
    timestamp = Column(DateTime, default=_now, nullable=False, index=True)


class Metric(Base):
    """Time-series numeric metric for charts. Retention: METRICS_RETENTION_DAYS."""
    __tablename__ = "metrics"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(64), nullable=False, index=True)
    node_id = Column(String(64), nullable=True, index=True)
    value = Column(Float, nullable=False)
    timestamp = Column(DateTime, default=_now, nullable=False, index=True)
