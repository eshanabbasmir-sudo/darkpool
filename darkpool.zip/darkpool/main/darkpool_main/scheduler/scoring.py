"""Workload scheduler.

Algorithm (configurable via SCHEDULER_STRATEGY):

    best-fit  (default): Score the node whose remaining capacity *after*
             placing the workload is smallest. Tends to pack workloads
             tightly and leave larger nodes free for big jobs.
    worst-fit:  Pick the node with the most remaining capacity after placement.
             Spreads workloads out.
    first-fit:  First node that satisfies the request, in registration order.

Scoring (best-fit / worst-fit):

    score = w_cpu * cpu_left_after + w_ram * ram_left_after_bytes
          + w_disk * disk_left_after_bytes + w_load * load_avg_1

The weights are configurable via env (SCHEDULER_SCORE_WEIGHT_*).
Lower score = preferred for best-fit. Higher = preferred for worst-fit.

Each candidate is filtered for:
    - node is ONLINE (UNSTABLE accepted only if no ONLINE alternative)
    - node is not draining / disabled
    - capabilities ⊇ workload.features_required
    - remaining capacity >= requested (respecting overcommit settings)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from sqlalchemy.orm import Session

from darkpool_main.config import get_settings
from darkpool_main.database.models import Node, NodeStatus
from darkpool_main.resource_manager.pool import (
    NodeCapacity,
    _node_is_schedulable,
    list_schedulable_nodes,
    reserve_atomic,
)


@dataclass
class SchedulerDecision:
    node_id: str
    score: float
    reason: str


def _feature_match(node_features: list[str], required: list[str]) -> bool:
    nf = set(node_features or [])
    return all(r in nf for r in (required or []))


def _score(cap: NodeCapacity, cpu_req: int, ram_req: int, disk_req: int, load: float) -> float:
    s = get_settings()
    cpu_left = cap.cpu_available - cpu_req
    ram_left = cap.ram_available_bytes - ram_req
    disk_left = cap.disk_available_bytes - disk_req
    return (
        s.scheduler_score_weight_cpu * cpu_left
        + s.scheduler_score_weight_ram * (ram_left / (1024 * 1024))
        + s.scheduler_score_weight_disk * (disk_left / (1024 * 1024))
        + s.scheduler_score_weight_load * load
    )


def select_node(
    db: Session,
    cpu_req: int,
    ram_bytes_req: int,
    disk_bytes_req: int,
    features_required: list[str] | None = None,
    exclude_node_ids: list[str] | None = None,
) -> Optional[SchedulerDecision]:
    settings = get_settings()
    features_required = features_required or []
    exclude_node_ids = set(exclude_node_ids or [])

    candidates: list[tuple[Node, NodeCapacity, float]] = []
    for node in list_schedulable_nodes(db):
        if node.id in exclude_node_ids:
            continue
        feats = (node.capabilities or {}).get("features", [])
        if not _feature_match(feats, features_required):
            continue
        cap = _capacity_for_safe(db, node)
        if cap is None:
            continue
        if cap.cpu_available < cpu_req and not settings.overcommit_cpu:
            continue
        if cap.ram_available_bytes < ram_bytes_req and not settings.overcommit_ram:
            continue
        if cap.disk_available_bytes < disk_bytes_req:
            continue
        load = (node.resources.load_avg_1 if node.resources else 0.0) or 0.0
        s = _score(cap, cpu_req, ram_bytes_req, disk_bytes_req, load)
        candidates.append((node, cap, s))

    if not candidates:
        return None

    if settings.scheduler_strategy == "first-fit":
        chosen = candidates[0]
    elif settings.scheduler_strategy == "worst-fit":
        chosen = max(candidates, key=lambda t: t[2])
    else:  # best-fit (default)
        chosen = min(candidates, key=lambda t: t[2])

    node, cap, score = chosen
    return SchedulerDecision(
        node_id=node.id,
        score=score,
        reason=f"strategy={settings.scheduler_strategy} score={score:.2f}",
    )


def _capacity_for_safe(db: Session, node: Node) -> NodeCapacity | None:
    # Import inside function to avoid circular import in tests
    from darkpool_main.resource_manager.pool import _capacity_for
    return _capacity_for(db, node)


def schedule(
    db: Session,
    workload_id: str,
    cpu_req: int,
    ram_bytes_req: int,
    disk_bytes_req: int,
    features_required: list[str] | None = None,
    exclude_node_ids: list[str] | None = None,
) -> Optional[str]:
    """Pick a node and atomically reserve resources. Returns node_id or None.

    The atomic reservation prevents two concurrent requests from allocating
    the same capacity on the same node.
    """
    decision = select_node(
        db,
        cpu_req,
        ram_bytes_req,
        disk_bytes_req,
        features_required,
        exclude_node_ids,
    )
    if decision is None:
        return None
    ok = reserve_atomic(
        db,
        decision.node_id,
        workload_id,
        cpu_req,
        ram_bytes_req,
        disk_bytes_req,
    )
    if not ok:
        # Race: someone else took the slot. Retry once without the chosen node.
        return schedule(
            db,
            workload_id,
            cpu_req,
            ram_bytes_req,
            disk_bytes_req,
            features_required,
            (exclude_node_ids or []) + [decision.node_id],
        )
    return decision.node_id
