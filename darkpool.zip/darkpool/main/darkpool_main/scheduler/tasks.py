"""APScheduler background tasks: node state machine + metric collection."""
from __future__ import annotations

from datetime import datetime, timezone

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from darkpool_main.database.models import Metric, Node, NodeStatus
from darkpool_main.database.session import db_session
from darkpool_main.node_manager.manager import update_node_state_machine
from darkpool_main.resource_manager.pool import aggregate, _capacity_for

_scheduler: AsyncIOScheduler | None = None


def start_scheduler() -> AsyncIOScheduler:
    global _scheduler
    if _scheduler is not None:
        return _scheduler
    _scheduler = AsyncIOScheduler()
    _scheduler.add_job(_tick_state_machine, "interval", seconds=5, id="state-machine")
    _scheduler.add_job(_tick_metrics, "interval", seconds=15, id="metrics")
    _scheduler.start()
    return _scheduler


def stop_scheduler() -> None:
    global _scheduler
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None


def _tick_state_machine() -> None:
    with db_session() as db:
        update_node_state_machine(db)


def _tick_metrics() -> None:
    with db_session() as db:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        nodes = db.query(Node).filter(Node.is_main.is_(False)).all()
        for n in nodes:
            res = n.resources
            if res is None:
                continue
            for name, value in [
                ("cpu_usage_pct", res.cpu_usage_pct),
                ("ram_used_bytes", res.ram_used_bytes),
                ("disk_free_bytes", res.disk_free_bytes),
                ("load_avg_1", res.load_avg_1),
            ]:
                db.add(Metric(name=name, node_id=n.id, value=float(value), timestamp=now))
        # Pool-level metrics
        pool = aggregate(db)
        for name, value in [
            ("pool.cpu_total", pool.cpu_total),
            ("pool.cpu_allocated", pool.cpu_allocated),
            ("pool.ram_total_bytes", pool.ram_total_bytes),
            ("pool.ram_allocated_bytes", pool.ram_allocated_bytes),
            ("pool.nodes_online", pool.nodes_online),
        ]:
            db.add(Metric(name=name, node_id=None, value=float(value), timestamp=now))
