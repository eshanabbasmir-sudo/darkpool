"""Scheduler package.

Exposes:
    - scoring.schedule(): workload placement decision
    - tasks.start_scheduler(): background metric/state-machine ticks
"""
from darkpool_main.scheduler.scoring import schedule, select_node  # noqa: F401
