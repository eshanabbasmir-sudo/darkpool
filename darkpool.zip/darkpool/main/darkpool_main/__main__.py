"""Main entrypoint: `python -m darkpool_main` or `uvicorn darkpool_main.app:app`."""
from __future__ import annotations

import uvicorn

from darkpool_main.app import app  # noqa: F401


def main() -> None:
    uvicorn.run(
        "darkpool_main.app:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info",
    )


if __name__ == "__main__":
    main()
