"""Container runtime abstraction.

v1: Docker via subprocess (no docker-py dependency). containerd/podman could
be added by extending the same interface.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from typing import Any


class ContainerRuntime:
    """Tiny wrapper around the docker CLI."""

    def __init__(self, runtime: str = "docker"):
        if not shutil.which(runtime):
            raise RuntimeError(f"container runtime '{runtime}' not found on PATH")
        self.runtime = runtime

    def is_available(self) -> bool:
        try:
            subprocess.run([self.runtime, "info"], check=False, capture_output=True, timeout=5)
            return True
        except Exception:
            return False

    def run(
        self,
        *,
        name: str,
        image: str,
        command: str | None = None,
        env: dict[str, str] | None = None,
        cpu_limit: int = 1,
        ram_limit_bytes: int = 512 * 1024 * 1024,
        disk_limit_bytes: int | None = None,
        network: str = "bridge",
        workspace_token: str | None = None,
    ) -> str:
        """Start a container with resource limits. Returns container ID."""
        args = [
            self.runtime, "run", "-d",
            "--name", name,
            "--restart", "no",
            "--cpus", str(cpu_limit),
            "--memory", str(ram_limit_bytes),
            "--network", network,
            # Security hardening
            "--security-opt", "no-new-privileges",
            "--cap-drop", "ALL",
            "--read-only",
            "--tmpfs", "/tmp:rw,size=64m",
        ]
        if disk_limit_bytes:
            # Quota-based disk limit (assumes overlay2 + quota)
            args.extend(["--storage-opt", f"size={disk_limit_bytes // (1024*1024)}m"])
        if env:
            for k, v in env.items():
                args.extend(["-e", f"{k}={v}"])
        if workspace_token:
            args.extend(["-e", f"DARKPOOL_WORKSPACE_TOKEN={workspace_token}"])
            args.extend(["-e", f"DARKPOOL_MAIN_URL={__import__('os').environ.get('MAIN_URL','')}"])
        # Inject darkpool-* helpers into the container PATH
        args.extend(["-v", "/opt/darkpool/workspace-tools:/opt/darkpool:ro"])
        args.extend(["-e", "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/opt/darkpool"])
        args.append(image)
        if command:
            args.extend(command.split())

        proc = subprocess.run(args, capture_output=True, text=True, timeout=60)
        if proc.returncode != 0:
            raise RuntimeError(f"docker run failed: {proc.stderr.strip()}")
        return proc.stdout.strip()

    def stop(self, container_id_or_name: str, timeout: int = 15) -> bool:
        proc = subprocess.run(
            [self.runtime, "stop", "-t", str(timeout), container_id_or_name],
            capture_output=True, text=True, timeout=60,
        )
        return proc.returncode == 0

    def rm(self, container_id_or_name: str) -> bool:
        subprocess.run(
            [self.runtime, "rm", "-f", container_id_or_name],
            capture_output=True, text=True, timeout=30,
        )
        return True

    def inspect_state(self, container_id: str) -> dict[str, Any] | None:
        proc = subprocess.run(
            [self.runtime, "inspect", "--format", "{{json .State}}", container_id],
            capture_output=True, text=True, timeout=10,
        )
        if proc.returncode != 0:
            return None
        try:
            return json.loads(proc.stdout.strip())
        except json.JSONDecodeError:
            return None

    def status(self, container_id: str) -> str:
        """Return one of: running, exited, failed, unknown."""
        state = self.inspect_state(container_id)
        if state is None:
            return "unknown"
        status_str = state.get("Status", "unknown")
        if status_str == "running":
            return "running"
        if status_str == "exited":
            exit_code = int(state.get("ExitCode", -1))
            return "failed" if exit_code != 0 else "stopped"
        return "unknown"
