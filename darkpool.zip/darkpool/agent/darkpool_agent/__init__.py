"""darkpool-agent — Supporter VPS worker.

Responsibilities:
    1. Register with Main (one-time, using registration token + ed25519 keypair)
    2. Persist node_id + node_token to /etc/darkpool/agent.conf (chmod 600)
    3. Periodically:
       a. Measure local resources (psutil)
       b. POST heartbeat to /api/nodes/heartbeat
       c. Long-poll /api/agent/commands for instructions
    4. Execute received commands:
       - start_workload  -> docker container run with CPU/RAM/disk limits
       - stop_workload   -> docker container stop
    5. Reconnect with exponential backoff on Main unavailability
    6. NEVER expose docker socket to the network

The agent is intentionally small (single Python file plus helpers).
"""
from __future__ import annotations

__version__ = "1.0.0"
