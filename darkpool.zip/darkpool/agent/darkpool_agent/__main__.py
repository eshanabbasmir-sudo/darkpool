"""Entrypoint for `python -m darkpool_agent`."""
from darkpool_agent.agent import main

if __name__ == "__main__":
    main()
