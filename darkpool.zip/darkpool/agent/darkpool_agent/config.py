"""Agent configuration."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _int(v: str | None, default: int) -> int:
    try:
        return int(v) if v is not None else default
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class AgentConfig:
    main_url: str = field(default_factory=lambda: os.getenv("MAIN_URL", "http://localhost:8000"))
    node_id: str = field(default_factory=lambda: os.getenv("NODE_ID", ""))
    node_token: str = field(default_factory=lambda: os.getenv("NODE_TOKEN", ""))
    registration_token: str = field(default_factory=lambda: os.getenv("REGISTRATION_TOKEN", ""))
    advertised_name: str = field(default_factory=lambda: os.getenv("ADVERTISED_NAME", ""))
    heartbeat_interval_sec: int = field(
        default_factory=lambda: _int(os.getenv("HEARTBEAT_INTERVAL_SEC"), 10)
    )
    resource_refresh_interval_sec: int = field(
        default_factory=lambda: _int(os.getenv("RESOURCE_REFRESH_INTERVAL_SEC"), 5)
    )
    cpu_reserve: int = field(default_factory=lambda: _int(os.getenv("CPU_RESERVE"), 1))
    ram_reserve_mb: int = field(default_factory=lambda: _int(os.getenv("RAM_RESERVE_MB"), 1024))
    disk_reserve_gb: int = field(default_factory=lambda: _int(os.getenv("DISK_RESERVE_GB"), 5))
    config_path: Path = field(
        default_factory=lambda: Path(os.getenv("AGENT_CONFIG_PATH", "/etc/darkpool/agent.conf"))
    )
    key_path: Path = field(
        default_factory=lambda: Path(os.getenv("AGENT_KEY_PATH", "/etc/darkpool/agent.key"))
    )
    docker_socket: str = field(default_factory=lambda: os.getenv("DOCKER_SOCKET", "unix:///var/run/docker.sock"))


def get_config() -> AgentConfig:
    return AgentConfig()
