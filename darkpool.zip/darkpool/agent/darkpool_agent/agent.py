"""darkpool-agent main loop.

Steps:
    1. Load or generate ed25519 keypair.
    2. Load or create agent.conf.
    3. If no node_id: register with Main (POST /api/nodes/register).
    4. Start heartbeat loop (every HEARTBEAT_INTERVAL_SEC).
    5. Start command-poll loop (every RESOURCE_REFRESH_INTERVAL_SEC).
    6. On Main unavailability: exponential backoff, never crash.
"""
from __future__ import annotations

import logging
import os
import socket
import sys
import threading
import time
from pathlib import Path
from typing import Any

import httpx

from darkpool_agent.config import get_config
from darkpool_agent.keys import (
    generate_keypair,
    load_config,
    load_private_key,
    save_config,
    sign_message,
)
from darkpool_agent.resources import measure_all, measure_static
from darkpool_agent.runtime import ContainerRuntime

log = logging.getLogger("darkpool-agent")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    stream=sys.stdout,
)


class DarkPoolAgent:
    def __init__(self, config=None, runtime=None):
        self.config = config or get_config()
        self.runtime = runtime or (ContainerRuntime("docker") if self._docker_available() else None)
        self.priv_key = None
        self.public_pem: str | None = None
        self.node_id: str = self.config.node_id
        self.node_uuid: str = ""
        self.node_token: str = self.config.node_token
        self._stop = threading.Event()
        self._backoff_sec = 1.0

    def _docker_available(self) -> bool:
        try:
            from shutil import which
            return which("docker") is not None
        except Exception:
            return False

    # --- Registration ------------------------------------------------------

    def ensure_registered(self) -> bool:
        cfg = load_config(self.config.config_path)
        if cfg:
            self.node_id = cfg["node_id"]
            self.node_uuid = cfg.get("node_uuid", "")
            self.node_token = cfg["node_token"]
            log.info("loaded existing config: node_id=%s", self.node_id)
        if self._ensure_keypair():
            return True
        return self._register()

    def _ensure_keypair(self) -> bool:
        if self.config.key_path.exists():
            self.priv_key = load_private_key(self.config.key_path)
            self.public_pem = self.config.key_path.read_bytes().decode("utf-8", errors="ignore")
            # Extract the public key portion
            from cryptography.hazmat.primitives import serialization
            self.public_pem = self.priv_key.public_key().public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo,
            ).decode()
            return bool(self.node_id and self.node_token)
        return False

    def _register(self) -> bool:
        log.info("generating ed25519 keypair at %s", self.config.key_path)
        priv_pem, pub_pem = generate_keypair(self.config.key_path)
        self.priv_key = load_private_key(self.config.key_path)
        self.public_pem = pub_pem

        static = measure_static()
        body = {
            "registration_token": self.config.registration_token,
            "advertised_name": self.config.advertised_name or socket.gethostname(),
            "hostname": static["hostname"],
            "public_key_pem": pub_pem,
            "capabilities": static["capabilities"],
            "os": static["os"],
            "kernel": static["kernel"],
            "arch": static["arch"],
            "container_runtime": static["container_runtime"],
            "cpu_model": static["cpu_model"],
            "cpu_total": static["cpu_total"],
            "ram_total_bytes": static["ram_total_bytes"],
            "disk_total_bytes": static["disk_total_bytes"],
        }
        url = f"{self.config.main_url}/api/nodes/register"
        log.info("POST %s", url)
        try:
            r = httpx.post(url, json=body, timeout=30.0)
            r.raise_for_status()
            data = r.json()
        except Exception as e:
            log.error("registration failed: %s", e)
            return False

        self.node_id = data["node_id"]
        self.node_uuid = data["node_uuid"]
        self.node_token = data["node_token"]
        save_config(
            self.config.config_path,
            node_id=self.node_id,
            node_uuid=self.node_uuid,
            node_token=self.node_token,
            main_url=self.config.main_url,
        )
        log.info("registered: node_id=%s node_uuid=%s", self.node_id, self.node_uuid)
        print("\n=== Node registration successful ===")
        print(f"Node ID: {self.node_id}")
        print(f"Node UUID: {self.node_uuid}")
        print(f"Status: ONLINE")
        print(f"Connected to: {self.config.main_url}")
        print("====================================\n")
        return True

    # --- Heartbeat --------------------------------------------------------

    def _signed_headers(self, body: bytes = b"") -> dict[str, str]:
        ts = str(int(time.time()))
        msg = f"{ts}|"
        if body:
            msg += body.decode("utf-8", errors="ignore")
        sig = sign_message(self.priv_key, msg) if self.priv_key else ""
        return {
            "X-DarkPool-Node": self.node_uuid or self.node_id,
            "X-DarkPool-Token": self.node_token,
            "X-DarkPool-Timestamp": ts,
            "X-DarkPool-Signature": sig,
        }

    def heartbeat_once(self) -> bool:
        if not self.node_id or not self.node_token:
            return False
        payload = measure_all()
        url = f"{self.config.main_url}/api/nodes/heartbeat"
        try:
            r = httpx.post(url, json=payload, headers=self._signed_headers(), timeout=10.0)
            if r.status_code == 401:
                log.error("heartbeat unauthorized; rotation may be required")
                return False
            r.raise_for_status()
            self._backoff_sec = 1.0
            return True
        except Exception as e:
            log.warning("heartbeat failed (will retry in %.1fs): %s", self._backoff_sec, e)
            time.sleep(self._backoff_sec)
            self._backoff_sec = min(self._backoff_sec * 2, 60.0)
            return False

    # --- Command poll -----------------------------------------------------

    def poll_commands_once(self) -> None:
        if not self.node_id:
            return
        url = f"{self.config.main_url}/api/agent/commands"
        try:
            r = httpx.get(url, headers=self._signed_headers(), timeout=15.0)
            r.raise_for_status()
        except Exception as e:
            log.warning("command poll failed: %s", e)
            return
        for cmd in r.json().get("commands", []):
            try:
                self._handle_command(cmd)
            except Exception as e:
                log.exception("command %s failed: %s", cmd.get("type"), e)

    def _handle_command(self, cmd: dict[str, Any]) -> None:
        ctype = cmd.get("type")
        if ctype == "start_workload":
            self._start_workload(cmd)
        elif ctype == "stop_workload":
            self._stop_workload(cmd)
        elif ctype == "ping":
            log.info("ping received from Main")
        else:
            log.warning("unknown command: %s", ctype)

    def _start_workload(self, cmd: dict[str, Any]) -> None:
        if self.runtime is None:
            log.error("no container runtime available; cannot start workload")
            self._report_status(cmd["workload_id"], "failed", error="no container runtime")
            return
        name = f"darkpool-{cmd['workload_id'][:12]}"
        log.info("starting workload %s image=%s", cmd["workload_id"], cmd["image"])
        try:
            cid = self.runtime.run(
                name=name,
                image=cmd["image"],
                command=cmd.get("command"),
                env=cmd.get("env") or {},
                cpu_limit=cmd.get("cpu_limit", 1),
                ram_limit_bytes=cmd.get("ram_limit_bytes", 512 * 1024 * 1024),
                disk_limit_bytes=cmd.get("disk_limit_bytes"),
                network=cmd.get("network", "bridge"),
                workspace_token=cmd.get("workspace_token"),
            )
        except Exception as e:
            log.error("docker run failed: %s", e)
            self._report_status(cmd["workload_id"], "failed", error=str(e))
            return
        self._report_status(cmd["workload_id"], "running", container_id=cid)

    def _stop_workload(self, cmd: dict[str, Any]) -> None:
        if self.runtime is None:
            return
        cid = cmd.get("container_id") or f"darkpool-{cmd['workload_id'][:12]}"
        log.info("stopping workload %s (container=%s)", cmd["workload_id"], cid)
        self.runtime.stop(cid)
        self.runtime.rm(cid)
        self._report_status(cmd["workload_id"], "stopped")

    def _report_status(self, workload_id: str, status: str, error: str | None = None, container_id: str | None = None) -> None:
        url = f"{self.config.main_url}/api/agent/workload/{workload_id}/status"
        body = {"status": status, "error": error, "container_id": container_id}
        try:
            r = httpx.post(url, json=body, headers=self._signed_headers(), timeout=10.0)
            r.raise_for_status()
        except Exception as e:
            log.warning("status report failed: %s", e)

    # --- Main loop --------------------------------------------------------

    def run(self) -> None:
        log.info("darkpool-agent starting")
        while not self._stop.is_set():
            if self.ensure_registered():
                break
            log.warning("not registered yet; retrying in 5s")
            self._stop.wait(5.0)
            if self._stop.is_set():
                return

        hb_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        cmd_thread = threading.Thread(target=self._cmd_loop, daemon=True)
        hb_thread.start()
        cmd_thread.start()

        try:
            while not self._stop.is_set():
                self._stop.wait(1.0)
        except KeyboardInterrupt:
            log.info("shutting down")
            self._stop.set()

    def _heartbeat_loop(self) -> None:
        while not self._stop.is_set():
            self.heartbeat_once()
            self._stop.wait(self.config.heartbeat_interval_sec)

    def _cmd_loop(self) -> None:
        while not self._stop.is_set():
            self.poll_commands_once()
            self._stop.wait(self.config.resource_refresh_interval_sec)

    def stop(self) -> None:
        self._stop.set()


def main() -> None:
    agent = DarkPoolAgent()
    agent.run()


if __name__ == "__main__":
    main()
