"""Ed25519 keypair management for node authentication."""
from __future__ import annotations

import json
import os
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


def generate_keypair(key_path: Path) -> tuple[str, str]:
    """Generate ed25519 keypair, save private key to `key_path` (chmod 600),
    return (private_pem, public_pem)."""
    key_path.parent.mkdir(parents=True, exist_ok=True)
    priv = Ed25519PrivateKey.generate()
    priv_pem = priv.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode()
    pub_pem = priv.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode()
    key_path.write_text(priv_pem)
    os.chmod(key_path, 0o600)
    return priv_pem, pub_pem


def load_private_key(key_path: Path):
    from cryptography.hazmat.primitives import serialization
    return serialization.load_pem_private_key(key_path.read_bytes(), password=None)


def sign_message(priv, message: str) -> str:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    if not isinstance(priv, Ed25519PrivateKey):
        raise TypeError("expected Ed25519PrivateKey")
    return priv.sign(message.encode()).hex()


def save_config(config_path: Path, *, node_id: str, node_uuid: str, node_token: str, main_url: str) -> None:
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps({
        "node_id": node_id,
        "node_uuid": node_uuid,
        "node_token": node_token,
        "main_url": main_url,
    }, indent=2))
    os.chmod(config_path, 0o600)


def load_config(config_path: Path) -> dict | None:
    if not config_path.exists():
        return None
    try:
        return json.loads(config_path.read_text())
    except Exception:
        return None
