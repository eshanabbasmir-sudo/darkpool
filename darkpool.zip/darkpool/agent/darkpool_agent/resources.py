"""Local resource measurement. Uses psutil.

The Main NEVER trusts client-submitted resource values — agents re-measure
on every heartbeat.
"""
from __future__ import annotations

import os
import platform
import shutil
import socket
import time
from typing import Any

import psutil


def measure_all() -> dict[str, Any]:
    cpu = measure_cpu()
    ram = measure_ram()
    disk = measure_disk()
    net = measure_net()
    sysinfo = measure_system()
    return {
        "status": "online",
        "cpu_usage": cpu["cpu_usage"],
        "load_avg_1": cpu["load_avg_1"],
        "load_avg_5": cpu["load_avg_5"],
        "load_avg_15": cpu["load_avg_15"],
        "ram_used": ram["ram_used"],
        "ram_total": ram["ram_total"],
        "ram_cached": ram["ram_cached"],
        "ram_free": ram["ram_free"],
        "disk_total": disk["disk_total"],
        "disk_free": disk["disk_free"],
        "filesystem": disk["filesystem"],
        "mount_point": disk["mount_point"],
        "rx_bytes": net["rx_bytes"],
        "tx_bytes": net["tx_bytes"],
        "uptime": sysinfo["uptime"],
    }


def measure_static() -> dict[str, Any]:
    """Static info reported once at registration."""
    cpu = measure_cpu()
    ram = measure_ram()
    disk = measure_disk()
    return {
        "hostname": socket.gethostname(),
        "os": platform.platform(),
        "kernel": platform.release(),
        "arch": platform.machine(),
        "container_runtime": detect_runtime(),
        "cpu_model": cpu["cpu_model"],
        "cpu_total": cpu["cpu_total"],
        "ram_total_bytes": ram["ram_total"],
        "disk_total_bytes": disk["disk_total"],
        "capabilities": detect_capabilities(),
    }


def measure_cpu() -> dict[str, Any]:
    cpu_total = os.cpu_count() or 0
    try:
        cpu_model = platform.processor() or "unknown"
    except Exception:
        cpu_model = "unknown"
    try:
        load1, load5, load15 = os.getloadavg()
    except (OSError, AttributeError):
        load1 = load5 = load15 = 0.0
    try:
        cpu_usage = psutil.cpu_percent(interval=0.5)
    except Exception:
        cpu_usage = 0.0
    return {
        "cpu_total": cpu_total,
        "cpu_model": cpu_model,
        "cpu_usage": cpu_usage,
        "load_avg_1": load1,
        "load_avg_5": load5,
        "load_avg_15": load15,
    }


def measure_ram() -> dict[str, int]:
    vm = psutil.virtual_memory()
    return {
        "ram_total": int(vm.total),
        "ram_used": int(vm.used),
        "ram_free": int(vm.free),
        "ram_cached": int(getattr(vm, "cached", 0) or getattr(vm, "buffers", 0) or 0),
    }


def measure_disk(path: str = "/") -> dict[str, Any]:
    try:
        usage = shutil.disk_usage(path)
        st = os.statvfs(path)
        return {
            "disk_total": int(usage.total),
            "disk_free": int(usage.free),
            "disk_used": int(usage.used),
            "filesystem": "ext4",  # best-effort; could parse /proc/mounts
            "mount_point": path,
        }
    except Exception:
        return {
            "disk_total": 0, "disk_free": 0, "disk_used": 0,
            "filesystem": None, "mount_point": path,
        }


def measure_net() -> dict[str, int]:
    """Return cumulative RX/TX across all interfaces."""
    try:
        netio = psutil.net_io_counters()
        return {"rx_bytes": int(netio.bytes_recv), "tx_bytes": int(netio.bytes_sent)}
    except Exception:
        return {"rx_bytes": 0, "tx_bytes": 0}


def measure_system() -> dict[str, Any]:
    try:
        uptime = int(time.time() - psutil.boot_time())
    except Exception:
        uptime = 0
    return {"uptime": uptime}


def detect_runtime() -> str | None:
    for rt in ["docker", "containerd", "podman"]:
        if shutil.which(rt):
            return rt
    return None


def detect_capabilities() -> dict[str, Any]:
    """Advertise node capabilities."""
    feats = ["ubuntu"] if "ubuntu" in platform.platform().lower() else []
    if shutil.which("docker"):
        feats.append("docker")
    return {
        "architecture": platform.machine(),
        "container_runtime": detect_runtime(),
        "features": feats,
    }
