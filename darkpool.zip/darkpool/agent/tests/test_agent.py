"""Agent-side smoke tests: resource measurement + keypair generation."""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

# Ensure darkpool_agent is importable
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def test_measure_all_returns_dict():
    from darkpool_agent.resources import measure_all
    out = measure_all()
    assert isinstance(out, dict)
    assert "cpu_usage" in out
    assert "ram_total" in out
    assert "disk_total" in out
    assert out["ram_total"] > 0


def test_measure_static_has_required_fields():
    from darkpool_agent.resources import measure_static
    s = measure_static()
    assert "cpu_total" in s and s["cpu_total"] > 0
    assert "ram_total_bytes" in s and s["ram_total_bytes"] > 0
    assert "capabilities" in s and isinstance(s["capabilities"], dict)
    assert "features" in s["capabilities"]


def test_keypair_generation_roundtrip():
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from darkpool_agent.keys import (
        generate_keypair,
        load_private_key,
        sign_message,
    )
    with tempfile.TemporaryDirectory() as td:
        key_path = Path(td) / "test.key"
        priv_pem, pub_pem = generate_keypair(key_path)
        assert key_path.exists()
        assert os.stat(key_path).st_mode & 0o777 == 0o600
        priv = load_private_key(key_path)
        sig = sign_message(priv, "hello world")
        # Verify signature independently
        pub = serialization.load_pem_public_key(pub_pem.encode())
        assert isinstance(pub, Ed25519PublicKey)
        pub.verify(bytes.fromhex(sig), b"hello world")  # raises on invalid


def test_save_and_load_config():
    from darkpool_agent.keys import save_config, load_config
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "agent.conf"
        save_config(p, node_id="worker-x", node_uuid="node-abc", node_token="tok", main_url="http://x")
        cfg = load_config(p)
        assert cfg["node_id"] == "worker-x"
        assert cfg["node_token"] == "tok"
        assert os.stat(p).st_mode & 0o777 == 0o600
