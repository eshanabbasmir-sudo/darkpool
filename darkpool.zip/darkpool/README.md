# DarkPool

> **Distributed VPS Resource Pool — Main + Supporter**
>
> Make multiple independent VPSs behave like ONE resource pool at the
> management/workload level — while honestly preserving the fact that CPU,
> RAM, storage, and kernels physically remain on separate machines.

```
                         INTERNET
                            │
                            ▼
                   ┌─────────────────┐
                   │     MAIN VPS    │
                   │  API  Auth      │
                   │  Scheduler      │
                   │  Resource Pool  │
                   │  Node Manager   │
                   │  Gateway  DB    │
                   └────────┬────────┘
                            │  mTLS / signed heartbeats
                            │
          ┌─────────────────┼─────────────────┐
          ▼                 ▼                 ▼
   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
   │ SUPPORTER 1 │   │ SUPPORTER 2 │   │ SUPPORTER N │
   │ Node Agent  │   │ Node Agent  │   │ Node Agent  │
   │ Docker      │   │ Docker      │   │ Docker      │
   └─────────────┘   └─────────────┘   └─────────────┘
```

## What this is (and isn't)

**This is:**
- A single management plane that aggregates capacity across many VPSs
- A scheduler that places container workloads on the best-fit worker
- A virtual resource view (`df -h`, `free -h`, `nproc`, `neofetch`) exposed
  **inside user workspaces** so users perceive one pool
- Atomic, race-free resource allocation
- Heartbeat-driven node health state machine (ONLINE → UNSTABLE → OFFLINE)
- Admin dashboard + CLI + REST API + audit logs

**This is NOT:**
- A magic merger of physical RAM across kernels
- A distributed filesystem
- A modification of `/proc`, `/bin/df`, or any host binary
- A Kubernetes replacement

The aggregation is a **scheduling abstraction**. Each workload physically
runs on ONE worker. See `ARCHITECTURE.md` § "Honest Limitations".

## Repository layout

```
darkpool/
├── main/              # Main VPS server (FastAPI + SQLAlchemy + APScheduler)
│   ├── darkpool_main/
│   │   ├── api/        # REST endpoints (nodes, resources, workloads, system)
│   │   ├── auth/       # admin + node auth, RBAC, audit
│   │   ├── database/   # SQLAlchemy models, session, migrations
│   │   ├── scheduler/  # workload placement + background tasks
│   │   ├── resource_manager/  # atomic allocation + pool aggregation
│   │   ├── node_manager/      # registration, heartbeat, state machine
│   │   ├── dashboard/         # Jinja2 + HTMX admin UI
│   │   └── app.py             # FastAPI factory
│   └── tests/         # pytest suite (30 tests)
├── agent/             # darkpool-agent (worker-side)
│   ├── darkpool_agent/
│   │   ├── agent.py   # main loop: registration, heartbeat, command poll
│   │   ├── resources.py  # psutil-based measurement
│   │   ├── runtime.py    # Docker wrapper
│   │   └── keys.py       # ed25519 keypair
│   └── tests/
├── cli/               # `darkpool` admin CLI
│   └── darkpool_cli/
├── workspace-tools/   # darkpool-df, darkpool-free, darkpool-nproc, ...
├── install-main.sh    # One-shot Main VPS installer (systemd)
├── install-agent.sh   # One-shot Supporter VPS installer (systemd)
├── .env.example       # Configuration template
├── README.md          # This file
├── INSTALL.md         # Step-by-step install guide
├── ARCHITECTURE.md    # Component deep-dive
└── SECURITY.md        # Threat model + hardening checklist
```

## Quickstart (5 minutes)

### On the Main VPS

```bash
git clone <this-repo> darkpool
cd darkpool
sudo ./install-main.sh
# (prompts for admin username/password + public URL)
# → writes /opt/darkpool/main/.env with a generated NODE_REGISTRATION_TOKEN
# → starts darkpool-main.service
# → prints: "Node registration token: <TOKEN>"
```

### On each Supporter VPS

```bash
git clone <this-repo> darkpool
cd darkpool
sudo MAIN_URL=https://main.example.com \
     REGISTRATION_TOKEN=<TOKEN_FROM_ABOVE> \
     ./install-agent.sh
# (or run interactively and it will prompt)
# → installs Docker + agent
# → registers with Main
# → starts darkpool-agent.service
# → first heartbeat within ~10s
```

### Verify

On Main:
```bash
darkpool node list
darkpool resources
darkpool info
```

Open the dashboard at `https://main.example.com/` and log in.

## Core concepts

| Concept | What it means |
|--------|---------------|
| **Main VPS** | Controller. Runs API, scheduler, dashboard, DB. Does NOT run user workloads. |
| **Supporter VPS** | Worker. Runs the `darkpool-agent`, executes container workloads. |
| **Virtual Pool** | The aggregate view of all online supporter resources. A scheduling abstraction only. |
| **Allocation** | A reservation of (CPU, RAM, disk) on a single node for a single workload. Atomic. |
| **Workspace** | A user's container with private fs, network, env. Workspace tools injected via PATH. |
| **Reservation** | Per-node safety margin (CPU_RESERVE, RAM_RESERVE_MB, DISK_RESERVE_GB) never allocated. |
| **Drain mode** | Node stays online but refuses new placements; existing workloads continue. |
| **Workspace token** | Random 32-byte hex token injected into the container env. Used by `darkpool-info` to call Main. |

## Requirements

- Ubuntu 22.04+ (x86_64)
- Python 3.11+
- Docker (on supporters; optional on Main)
- 1 VPS for Main, 1+ for Supporters
- 1 GB RAM minimum per VPS (2 GB recommended for Main)

## License

MIT. See `LICENSE` (or include one).
