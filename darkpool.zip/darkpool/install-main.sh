#!/usr/bin/env bash
# install-main.sh — install the DarkPool Main VPS controller on Ubuntu 22.04+
#
# Usage:
#   sudo MAIN_URL=https://main.example.com ./install-main.sh
#   sudo ./install-main.sh --dev       # local dev install
#
# This script:
#   1. Installs system dependencies (Python 3.11, pip, venv, nginx optional)
#   2. Creates /opt/darkpool/main with a Python venv
#   3. Copies source code from the repo
#   4. Generates a .env from .env.example (interactive prompts for secrets)
#   5. Installs the darkpool-main.service systemd unit
#   6. Initializes the DB and bootstraps the admin user
#   7. Verifies the service is up
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="/opt/darkpool/main"
VENV_DIR="$INSTALL_DIR/venv"
SERVICE_FILE="/etc/systemd/system/darkpool-main.service"
ENV_FILE="$INSTALL_DIR/.env"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: must be run as root (use sudo)." >&2
  exit 1
fi

echo "=== DarkPool Main VPS installer ==="
echo "Repo:    $REPO_ROOT"
echo "Install: $INSTALL_DIR"
echo

# 1. System deps
echo "[1/7] Installing system dependencies..."
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  python3.11 python3.11-venv python3-pip ca-certificates curl \
  >/dev/null
if ! command -v nginx >/dev/null 2>&1; then
  echo "  (nginx not installed — Main will serve HTTP on :8000 directly."
  echo "   In production, put nginx in front for TLS termination.)"
fi
echo "  done."

# 2. Layout
echo "[2/7] Creating $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"
cp -r "$REPO_ROOT/main"/* "$INSTALL_DIR/"
cp "$REPO_ROOT/.env.example" "$INSTALL_DIR/.env.example"

# 3. Venv + Python deps
echo "[3/7] Creating Python venv and installing dependencies..."
python3.11 -m venv "$VENV_DIR"
"$VENV_DIR/bin/pip" install --quiet --upgrade pip
"$VENV_DIR/bin/pip" install --quiet "$INSTALL_DIR"
echo "  done."

# 4. .env (interactive)
echo "[4/7] Generating .env..."
if [[ ! -f "$ENV_FILE" ]]; then
  cp "$INSTALL_DIR/.env.example" "$ENV_FILE"

  read -r -p "  Public base URL [http://localhost:8000]: " MAIN_URL
  MAIN_URL="${MAIN_URL:-http://localhost:8000}"
  sed -i "s|^PUBLIC_BASE_URL=.*|PUBLIC_BASE_URL=$MAIN_URL|" "$ENV_FILE"

  read -r -p "  Admin username [admin]: " ADMIN_USER
  ADMIN_USER="${ADMIN_USER:-admin}"
  sed -i "s|^ADMIN_USERNAME=.*|ADMIN_USERNAME=$ADMIN_USER|" "$ENV_FILE"

  read -r -s -p "  Admin password: " ADMIN_PASS; echo
  if [[ -z "$ADMIN_PASS" ]]; then
    echo "ERROR: admin password is required." >&2
    exit 1
  fi
  sed -i "s|^ADMIN_PASSWORD=.*|ADMIN_PASSWORD=$ADMIN_PASS|" "$ENV_FILE"

  read -r -p "  Admin email [admin@example.com]: " ADMIN_EMAIL
  ADMIN_EMAIL="${ADMIN_EMAIL:-admin@example.com}"
  sed -i "s|^ADMIN_EMAIL=.*|ADMIN_EMAIL=$ADMIN_EMAIL|" "$ENV_FILE"

  # Generate random secrets
  SECRET=$(openssl rand -hex 32 2>/dev/null || python3 -c "import secrets; print(secrets.token_hex(32))")
  NODE_REG=$(openssl rand -hex 32 2>/dev/null || python3 -c "import secrets; print(secrets.token_hex(32))")
  sed -i "s|^SECRET_KEY=.*|SECRET_KEY=$SECRET|" "$ENV_FILE"
  sed -i "s|^NODE_REGISTRATION_TOKEN=.*|NODE_REGISTRATION_TOKEN=$NODE_REG|" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  echo
  echo "  >>> SAVE THIS — Node registration token (supporters need it):"
  echo "      $NODE_REG"
fi

# 5. systemd unit
echo "[5/7] Installing systemd unit..."
cat > "$SERVICE_FILE" <<UNIT
[Unit]
Description=DarkPool Main VPS Controller
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$VENV_DIR/bin/python -m darkpool_main
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable darkpool-main >/dev/null

# 6. Start
echo "[6/7] Starting darkpool-main.service..."
systemctl restart darkpool-main
sleep 3
if ! systemctl is-active --quiet darkpool-main; then
  echo "ERROR: service did not start. Check journal:" >&2
  journalctl -u darkpool-main -n 50 --no-pager
  exit 1
fi

# 7. Verify
echo "[7/7] Verifying..."
sleep 2
if curl -fsS "$MAIN_URL/health" >/dev/null 2>&1 || curl -fsS http://localhost:8000/health >/dev/null 2>&1; then
  echo "  ✓ Main is online."
else
  echo "  ! Health check failed (may need a few seconds to boot). Try:"
  echo "      curl http://localhost:8000/health"
fi

echo
echo "=== Installation complete ==="
echo "Dashboard:  $MAIN_URL/"
echo "Login with: $ADMIN_USER / (the password you set)"
echo "Logs:       journalctl -u darkpool-main -f"
echo
echo "Next steps:"
echo "  1. Add supporter VPSs by running install-agent.sh on each worker."
echo "  2. Use the registration token above when prompted."
echo "  3. Install nginx + Let's Encrypt in front of Main for HTTPS in production."
