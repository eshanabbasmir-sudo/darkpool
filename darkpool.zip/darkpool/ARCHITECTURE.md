# DarkPool Architecture

## Component map

```
                ┌─────────────────────────────────────────┐
                │                MAIN VPS                  │
                │                                          │
                │  ┌────────────────────────────────────┐ │
                │  │ FastAPI app (app.py)               │ │
                │  │  ├── api/auth.py     (login/logout)│ │
                │  │  ├── api/nodes.py    (register/hb) │ │
                │  │  ├── api/resources.py (pool view)  │ │
                │  │  ├── api/workloads.py (CRUD)        │ │
                │  │  ├── api/system.py   (status/metrics)│
                │  │  ├── dashboard/routes.py (HTML UI)  │ │
                │  │  └── utils/rate_limit.py            │ │
                │  └────────────────────────────────────┘ │
                │                                          │
                │  ┌────────────────────────────────────┐ │
                │  │ Scheduler (scheduler/)             │ │
                │  │  ├── scoring.py  (best-fit algo)   │ │
                │  │  └── tasks.py    (APScheduler)     │ │
                │  └────────────────────────────────────┘ │
                │                                          │
                │  ┌────────────────────────────────────┐ │
                │  │ Resource Manager                    │ │
                │  │  └── pool.py                       │ │
                │  │      ├── aggregate()               │ │
                │  │      ├── reserve_atomic()          │ │
                │  │      └── release()                 │ │
                │  └────────────────────────────────────┘ │
                │                                          │
                │  ┌────────────────────────────────────┐ │
                │  │ Node Manager (node_manager/)        │ │
                │  │  ├── register_node()                │ │
                │  │  ├── receive_heartbeat()            │ │
                │  │  ├── update_node_state_machine()   │ │
                │  │  ├── drain_node() / enable() ...    │ │
                │  │  └── rotate_credentials()          │ │
                │  └────────────────────────────────────┘ │
                │                                          │
                │  ┌────────────────────────────────────┐ │
                │  │ Database (SQLAlchemy)               │ │
                │  │  SQLite (dev) / PostgreSQL (prod)   │ │
                │  └────────────────────────────────────┘ │
                └─────────────────────────────────────────┘
                              ▲
                              │ HTTPS + signed heartbeats
                              │ X-DarkPool-Node, X-DarkPool-Token,
                              │ X-DarkPool-Timestamp, X-DarkPool-Signature
                              ▼
                ┌─────────────────────────────────────────┐
                │              SUPPORTER VPS               │
                │                                          │
                │  ┌────────────────────────────────────┐ │
                │  │ darkpool-agent                      │ │
                │  │  ├── agent.py (main loop)          │ │
                │  │  ├── resources.py (psutil measure) │ │
                │  │  ├── runtime.py (Docker wrapper)   │ │
                │  │  └── keys.py (ed25519 keypair)     │ │
                │  └────────────────────────────────────┘ │
                │                                          │
                │  ┌────────────────────────────────────┐ │
                │  │ Docker daemon (unix socket only)   │ │
                │  └────────────────────────────────────┘ │
                └─────────────────────────────────────────┘
```

## Module responsibilities

### Main VPS

| Module | Responsibility |
|--------|-----------------|
| `app.py` | FastAPI factory, lifespan, middleware (CORS, rate limit, request logging) |
| `config.py` | Single source of truth for all settings (env-driven) |
| `database/models.py` | SQLAlchemy ORM models (10 tables) |
| `database/session.py` | Engine + session factory; in-memory SQLite uses StaticPool |
| `database/migrations.py` | `create_all()` + admin bootstrap on first run |
| `auth/admin_auth.py` | Admin session creation/verification, SHA-256 hashed tokens, 12h TTL |
| `auth/node_auth.py` | Registration token, per-node ed25519 pubkeys, rotating node tokens, replay protection (±60s) |
| `auth/passwords.py` | PBKDF2-HMAC-SHA256, 200k iterations, salted |
| `auth/rbac.py` | FastAPI dependencies: `require_admin`, `require_user`, `current_user` |
| `auth/audit.py` | Single audit-log entrypoint |
| `node_manager/manager.py` | Registration, heartbeat ingest, state machine, drain/enable/disable/remove, credential rotation |
| `resource_manager/pool.py` | Aggregation, atomic reservation, release, overcommit enforcement |
| `scheduler/scoring.py` | best-fit / worst-fit / first-fit selection + atomic reserve |
| `scheduler/tasks.py` | APScheduler background ticks (state machine + metric collection) |
| `api/nodes.py` | REST: register, heartbeat, list, get, delete, drain, rotate, capacity |
| `api/resources.py` | REST: pool summary + per-node breakdown + capability listing |
| `api/workloads.py` | REST: create (with scheduler call), list, get, stop |
| `api/system.py` | REST: system status, metrics, events, audit, agent command long-poll |
| `dashboard/routes.py` | Server-rendered admin UI (Jinja2 + HTMX) |
| `utils/rate_limit.py` | In-memory per-IP sliding-window limiter |

### Supporter VPS

| Module | Responsibility |
|--------|-----------------|
| `agent.py` | Main loop: register → heartbeat → command poll; exponential backoff on failure |
| `resources.py` | Real CPU/RAM/disk/network/system measurement via psutil (never trust client input) |
| `runtime.py` | Docker subprocess wrapper: run with `--cpus`, `--memory`, `--security-opt no-new-privileges`, `--cap-drop ALL`, `--read-only` |
| `keys.py` | ed25519 keypair generation (chmod 600), config persistence |
| `config.py` | Agent-side env config |

### CLI + workspace tools

| Binary | Purpose |
|--------|---------|
| `darkpool` | Admin CLI (node/resources/workloads/info/events/login) |
| `darkpool-info` | User-facing neofetch-style summary (queries `/api/system/status`) |
| `darkpool-df` | Virtual `df` showing pool disk capacity (NOT host filesystem) |
| `darkpool-free` | Virtual `free` showing pool RAM |
| `darkpool-nproc` | Virtual `nproc` (pool total or `--workspace` for cgroup limit) |
| `darkpool-neofetch` | Neofetch-style ASCII + system info |

## Data model

```
users ─┬─< admin_sessions
       └─< workloads ─< resource_allocations >─ nodes
                                              ├─< node_credentials (1:1)
                                              ├─< node_resources   (1:1)
                                              └─< heartbeats       (1:N)

events, audit_logs, metrics  (system-wide time series)
```

### Concurrency model

**Resource allocation is atomic** (requirement #38):

1. `scheduler.schedule()` calls `select_node()` → returns best node ID
2. Calls `pool.reserve_atomic(node_id, workload_id, cpu, ram, disk)`
3. `reserve_atomic`:
   - Acquires mutex (SQLite) or `SELECT ... FOR UPDATE` (Postgres)
   - Re-reads current capacity from `resource_allocations` (sum of unreleased rows)
   - Verifies `available >= requested` (respecting reserves + overcommit settings)
   - Inserts new `ResourceAllocation` row
   - Commits
4. If two concurrent requests race for the last slot, exactly ONE succeeds;
   the other gets `False` and the scheduler retries with `exclude_node_ids`.

Verified by `test_reserve_atomic_concurrent_does_not_oversubscribe` (5 threads,
exactly 1 success).

## Node health state machine

```
                 heartbeat received
        ┌─────────────────────────────┐
        │                             ▼
   ┌─────────┐                ┌─────────┐
   │ ONLINE  │                │ ONLINE  │
   └─────────┘                └─────────┘
        │
        │ no heartbeat for UNSTABLE_THRESHOLD_SEC (15s default)
        ▼
   ┌──────────┐
   │ UNSTABLE │ ──── heartbeat received ────► ONLINE
   └──────────┘
        │
        │ no heartbeat for OFFLINE_THRESHOLD_SEC (45s default)
        ▼
   ┌──────────┐
   │ OFFLINE  │ ──── heartbeat + auth ────► ONLINE (recover)
   └──────────┘
        │
        │ admin disables / removes
        ▼
   ┌──────────┐
   │ DISABLED │ (terminal; agent may still be running but ignored)
   └──────────┘
```

**Drain mode** is orthogonal — a draining node stays ONLINE/UNSTABLE
for its workloads but is excluded from `list_schedulable_nodes()`.

## Scheduler algorithm

```python
score = w_cpu * (cpu_available - cpu_req)
      + w_ram * (ram_available_MB - ram_req_MB)
      + w_disk * (disk_available_MB - disk_req_MB)
      + w_load * load_avg_1
```

| Strategy | Selection |
|----------|-----------|
| `best-fit` (default) | Lowest score (packs tightly) |
| `worst-fit` | Highest score (spreads out) |
| `first-fit` | First candidate in registration order |

Weights configurable via `SCHEDULER_SCORE_WEIGHT_*` env vars.

**Filters** (all must pass for a node to be a candidate):
- `node.enabled == True`
- `node.draining == False`
- `node.status in (ONLINE, UNSTABLE)`
- `node.is_main == False`
- `capabilities.features ⊇ workload.features_required`
- `cpu_available >= cpu_req` (or `OVERCOMMIT_CPU=true`)
- `ram_available >= ram_req` (or `OVERCOMMIT_RAM=true`)
- `disk_available >= disk_req`

## Virtual resource view (the "df -h" requirement)

The user specifically asked for `df`/`free`/`nproc`/`neofetch` to show
**virtual pool** numbers inside user workspaces. The implementation:

1. Workspace tools (`darkpool-df`, `darkpool-free`, ...) live in
   `/opt/darkpool/workspace-tools/` on every supporter.
2. The agent mounts this directory read-only into every container at
   `/opt/darkpool` and prepends it to the container's `PATH`.
3. Inside the container, running `df -h` invokes `darkpool-df` (NOT
   `/bin/df`). The host's `df` binary is untouched.
4. The tools read `DARKPOOL_MAIN_URL` + `DARKPOOL_WORKSPACE_TOKEN` from
   the container env (also injected by the agent) and call Main's
   `/api/resources` endpoint.
5. Main returns the aggregated pool numbers. The tools print them in
   `df`/`free`/`nproc`-compatible format with a clear annotation that
   this is a virtual pool, not a single physical disk.

For `nproc`, two modes:
- `nproc` → pool CPU total
- `nproc --workspace` → this container's cgroup CPU quota (from `/sys/fs/cgroup/cpu.max`)

**Critical safety property:** the host's `/bin/df`, `/bin/free`, `/bin/nproc`,
and `/usr/bin/neofetch` are NEVER modified, replaced, or shadowed globally.
The virtualization happens ONLY inside container namespaces via PATH injection.

## Honest Limitations

**What v1 does NOT do** (and never claims to):

1. **Does NOT physically merge RAM across kernels.** A workload on Worker A
   cannot allocate RAM that physically lives on Worker B. The "virtual pool"
   is a scheduling/reporting abstraction only.

2. **Does NOT migrate running workloads.** If Worker A goes offline, its
   workloads are marked `UNKNOWN` (not destroyed). Re-starting them on
   another worker is a v2 feature ("Worker migration" in ROADMAP).

3. **Does NOT provide distributed storage.** Workload data lives on the
   worker where the container runs. If that worker goes offline, the data
   is inaccessible until the worker returns (or is permanently lost if
   the worker is destroyed). Future: replicated storage.

4. **Does NOT support multi-Main failover.** v1 has exactly one Main.
   If Main goes down, agents will retry with exponential backoff (up to
   60s) but no workload scheduling happens during the outage.

5. **Does NOT expose Docker sockets.** Agents talk to their local Docker
   daemon over the Unix socket only. No Docker API is exposed to the
   network. Users never talk to agents directly.

6. **Does NOT enable overcommit by default.** `OVERCOMMIT_CPU=false` and
   `OVERCOMMIT_RAM=false` by default. Even when enabled, it's clearly
   displayed in the dashboard and CLI.

## Future extensibility

The code is structured so the following can be added without rewrites:

- **Worker migration** — `node_manager` already preserves workload metadata
  on offline; add a migration scheduler that re-creates workloads on other
  nodes when storage allows.
- **Distributed storage** — `resource_manager` is storage-agnostic; add a
  `StorageBackend` interface (local, NFS, Ceph, etc.).
- **Replication** — `ResourceAllocation` rows are per-workload-per-node;
  extending to support replicas is a column addition.
- **Automatic failover** — heartbeat state machine already detects offline;
  add a policy layer that triggers migrations.
- **Autoscaling** — Main can call cloud provider APIs to spawn/drain
  supporters based on `pool.cpu_available` thresholds.
- **GPU workers** — `Node.capabilities` is a JSON column; scheduler already
  filters on `features_required`.
- **ARM workers** — agent's `measure_static()` reports `arch`; scheduler
  can be extended to match workload arch requirements.
- **Multiple Main controllers** — `database/session.py` is stateless;
  replace SQLite with Postgres + add a Main-Main consensus layer.
- **Usage billing** — `Metric` and `ResourceAllocation` tables already
  record everything needed.
- **Per-user quotas** — `User` table is ready for a `cpu_quota` column.
- **Priority queues** — `Workload` table is ready for a `priority` column.
- **Kubernetes / Nomad integration** — `scheduler/scoring.py` is pluggable;
  add a `KubeScheduler` class implementing the same interface.
- **WebSocket live metrics** — FastAPI supports it; the dashboard currently
  uses 15s page refresh which can be upgraded.
