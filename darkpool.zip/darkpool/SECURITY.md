# Security Policy

## Threat model

| Asset | Threat | Mitigation |
|-------|--------|-----------|
| Admin credentials | Brute force | PBKDF2-HMAC-SHA256 (200k iterations, salted); rate limit (120 req/min/IP); 12h session TTL |
| Admin session token | DB leak | Only SHA-256 hash stored; raw token returned once at login |
| Node registration token | Theft | Single token in `.env` (chmod 600); rotate via `darkpool node rotate <id>`; admins should rotate per-supporter |
| Node authentication | Compromised node | Per-node ed25519 keypair; rotating per-node tokens with one-step rollback window; signed heartbeats |
| Heartbeat replay | Capture/replay | `X-DarkPool-Timestamp` enforced ±60s; signature covers `timestamp|body` |
| Node token leak | Loss of confidentiality | Token hash stored; raw token returned ONCE at registration/rotation |
| Docker socket | Public exposure | NEVER exposed to network; agent uses local Unix socket only |
| Container escape | Privilege escalation | `--security-opt no-new-privileges`, `--cap-drop ALL`, `--read-only`, `--tmpfs /tmp` |
| User isolation | Cross-user access | Separate Docker networks per workload; container namespaces; no shared volumes |
| API abuse | DoS | Per-IP rate limit (120/min users, 600/min nodes); FastAPI request size limits |
| Secrets in code | Source leak | `.env` excluded from git; `.env.example` contains only placeholders |
| Audit trail | Tampering | `audit_logs` table is append-only by design; restrict DB access to Main process |

## Authentication layers

### Layer 1: Admin authentication (humans)
- Username + password → PBKDF2-HMAC-SHA256 verification
- On success: 32-byte URL-safe random session token
- SHA-256 of token stored in `admin_sessions.token_hash`
- Token sent to client as HTTP-only cookie + bearer token
- 12-hour TTL, refreshed on each request
- Logout revokes the session row

### Layer 2: Node authentication (machines)

**Registration** (one-time per supporter):
1. Admin gives operator a registration token (from `.env` `NODE_REGISTRATION_TOKEN`)
2. Agent generates ed25519 keypair locally (NEVER sent to Main in plaintext)
3. Agent POSTs to `/api/nodes/register` with:
   - registration_token (verified against env var)
   - public_key_pem (stored on Main)
   - advertised_name, capabilities, static resource info
4. Main creates `nodes` + `node_credentials` rows
5. Main returns `node_id` + `node_token` (random 32-byte hex)
6. Token hash stored in `node_credentials.current_token_hash`

**Heartbeat** (every 10s by default):
Each agent→Main request carries 4 headers:
```
X-DarkPool-Node:      <node_uuid>
X-DarkPool-Token:     <current_node_token>
X-DarkPool-Timestamp: <unix ts>
X-DarkPool-Signature: <ed25519 hex signature of "timestamp|body">
```

Main verifies:
1. Timestamp within ±60s (replay protection)
2. Token hash matches `current_token_hash` (or `previous_token_hash` during rotation)
3. Ed25519 signature verifies against stored public key

### Layer 3: User authentication (future)
v1 uses admin-only auth. Per-user RBAC infrastructure exists
(`UserRole.USER`, `require_user` dependency) but no user signup flow yet.

## Authorization (RBAC)

| Role | Permissions |
|------|------------|
| `admin` | All endpoints, dashboard, all workloads, node management |
| `user` | Own workloads only (read/stop), system info, resources |

`User.role` is an enum column. `require_admin` / `require_user` FastAPI
dependencies enforce this on every protected route.

For node-to-Main calls, the `authenticate_node` dependency verifies that
the requesting node is who it claims to be AND that the workload it's
reporting on belongs to it (`Workload.node_id == node.id`).

## Container isolation

Every workload container is started with:
```bash
docker run -d \
  --cpus <N> \
  --memory <bytes> \
  --network bridge \           # default isolated network
  --security-opt no-new-privileges \
  --cap-drop ALL \              # drop ALL Linux capabilities
  --read-only \                # rootfs read-only
  --tmpfs /tmp:rw,size=64m \    # only /tmp is writable, capped at 64 MiB
  ...
```

Additional protections:
- Each workload gets a unique Docker network (or `--network none` for max isolation)
- No host directories mounted except `/opt/darkpool/workspace-tools` **read-only**
- Environment variables scoped to the workload (`DARKPOOL_WORKSPACE_TOKEN`, `DARKPOOL_MAIN_URL`)
- Resource limits enforced by cgroups (visible via `nproc --workspace` reading `/sys/fs/cgroup/cpu.max`)

**User A cannot:**
- See User B's container (Docker API never exposed to users)
- See User B's IP (separate networks)
- Stop User B's workload (API authorization checks `workload.owner_id == user.id`)
- Inspect User B's processes (separate PID namespaces)
- Access User B's filesystem (separate mount namespaces + no shared volumes)
- Access User B's env vars (separate container envs)

## Least-privilege principle

- Agents can ONLY:
  - POST heartbeats (their own)
  - GET their own commands
  - POST status for workloads assigned to them
- Agents CANNOT:
  - List other nodes
  - Read other nodes' resources
  - Create/delete workloads
  - Access the dashboard
  - Modify any Main configuration

**Compromised supporter does NOT automatically compromise Main.**
The attacker gets at most:
- The ability to start/stop their own (assigned) workloads
- The ability to send fake heartbeats (which would mark the node unhealthy
  but not grant access to anything else)
- Their own ed25519 private key (which only authenticates THAT node)

To fully revoke a compromised supporter:
1. `darkpool node disable worker-X` (stops new scheduling)
2. `darkpool node remove worker-X` (marks OFFLINE, retains metadata)
3. Rotate `NODE_REGISTRATION_TOKEN` on Main (prevents re-registration)
4. Audit log shows all actions taken by that node

## Secrets management

| Secret | Storage | Rotation |
|--------|---------|----------|
| `SECRET_KEY` (session signing) | `/opt/darkpool/main/.env` chmod 600 | Manual; rotates all admin sessions |
| `ADMIN_PASSWORD` | Hashed in DB; raw value only in `.env` on first install | `darkpool login` → admin changes password (future) |
| `NODE_REGISTRATION_TOKEN` | `/opt/darkpool/main/.env` chmod 600 | Manual; restart Main after change |
| Node ed25519 private key | `/etc/darkpool/agent.key` chmod 600 | Per-node: `darkpool node rotate <id>` returns new token; agent generates new key on re-register |
| Node token (per-node) | Hashed in `node_credentials.current_token_hash`; raw value at `/etc/darkpool/agent.conf` chmod 600 | `darkpool node rotate <id>`; old token valid for one rotation window |

## Audit log

Every security-relevant action emits an `AuditLog` row:

```
actor: 'admin:1' | 'node:worker-01' | 'anon:register' | 'system'
action: 'login.success' | 'login.failed' | 'node.register' | 'node.drain' |
         'node.token_rotated' | 'workload.create' | 'workload.stop' | ...
target_type: 'node' | 'workload' | 'user' | ...
target_id: <id>
detail: <human-readable>
ip_address: <client IP>
timestamp: <UTC>
```

View via:
- Dashboard → Events section
- API: `GET /api/audit?hours=24`
- CLI: `darkpool events`

## TLS / mTLS

**v1 (default):** Plain HTTP between agent and Main. Put nginx + Let's
Encrypt in front of Main for production HTTPS. The agent verifies
the certificate chain via system CA.

**v1 + mTLS (opt-in):** Set `MTLS_ENABLED=true` and `MTLS_CA_DIR=/path/to/ca/`.
Main will require client cert verification for all `/api/nodes/*` and
`/api/agent/*` endpoints. Each agent needs a client cert signed by the
private CA. Future work: auto-mint per-node certs on registration.

## What to do if you suspect a breach

1. **Revoke the affected node:**
   ```bash
   darkpool node disable worker-XX
   darkpool node remove worker-XX
   ```
2. **Rotate the registration token** (prevents re-registration):
   - Edit `/opt/darkpool/main/.env` → new value for `NODE_REGISTRATION_TOKEN`
   - `systemctl restart darkpool-main`
3. **Audit the node's actions:**
   ```bash
   darkpool events | grep worker-XX
   curl $MAIN_URL/api/audit?hours=168 | jq '.[] | select(.actor|contains("worker-XX"))'
   ```
4. **Rotate the admin password** if Main itself is suspected compromised:
   - Update `.env` `ADMIN_PASSWORD`
   - `systemctl restart darkpool-main` (re-bootstraps if no admins exist;
     otherwise use the future `darkpool admin change-password` command)

## Reporting vulnerabilities

Please open a private security advisory rather than a public issue.
