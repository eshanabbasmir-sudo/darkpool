# Installation Guide

## Prerequisites

- Ubuntu 22.04+ on x86_64
- Root access (`sudo`)
- A public hostname for Main (e.g. `main.example.com`) with port 443 open
- For each Supporter: a public hostname or IP, port 443/80 reachable from Main

## Production deployment

### 1. Provision the Main VPS

```bash
ssh root@main.example.com

apt update && apt install -y git
git clone https://github.com/your-org/darkpool.git
cd darkpool

# Optional: pre-set env vars to make install non-interactive
export MAIN_URL=https://main.example.com
export ADMIN_USERNAME=admin
export ADMIN_PASSWORD='use-a-strong-password'
export ADMIN_EMAIL=admin@example.com

sudo -E ./install-main.sh
```

The installer will:
1. Install Python 3.11 + pip + venv
2. Create `/opt/darkpool/main/` with a venv
3. Generate `.env` from `.env.example` (random SECRET_KEY, random NODE_REGISTRATION_TOKEN)
4. Install the `darkpool-main.service` systemd unit
5. Start the service on `0.0.0.0:8000`

**Save the printed `NODE_REGISTRATION_TOKEN`** — supporters need it.

### 2. Put nginx + TLS in front (production)

```nginx
# /etc/nginx/sites-available/darkpool
server {
    listen 443 ssl http2;
    server_name main.example.com;

    ssl_certificate     /etc/letsencrypt/live/main.example.com/fullchain.pem;
    ssl_certificate_key  /etc/letsencrypt/live/main.example.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```bash
ln -s /etc/nginx/sites-available/darkpool /etc/nginx/sites-enabled/
certbot --nginx -d main.example.com
nginx -t && systemctl reload nginx
```

Update `/opt/darkpool/main/.env`:
```
PUBLIC_BASE_URL=https://main.example.com
```

### 3. Provision Supporter VPSs

On each supporter:

```bash
ssh root@worker-1.example.com

apt update && apt install -y git
git clone https://github.com/your-org/darkpool.git
cd darkpool

# Either pre-set env or run interactively:
export MAIN_URL=https://main.example.com
export REGISTRATION_TOKEN=<token-from-step-1>
export ADVERTISED_NAME=worker-1

sudo -E ./install-agent.sh
```

The installer will:
1. Install Python 3.11 + Docker (via get.docker.com)
2. Create `/opt/darkpool/agent/` + `/opt/darkpool/workspace-tools/`
3. Generate an ed25519 keypair at `/etc/darkpool/agent.key` (chmod 600)
4. Write `/etc/darkpool/agent.env` (chmod 600)
5. Register with Main, store the returned `node_token` in `/etc/darkpool/agent.conf`
6. Start `darkpool-agent.service`

Verify on Main:
```bash
darkpool node list
# should show worker-1 as ONLINE
```

### 4. Create a workload (smoke test)

```bash
darkpool login --username admin --password '...'
# export DARKPOOL_TOKEN=...

darkpool workload create --image alpine:3.19 --cpu 1 --ram 256 --disk 1 \
    --command "sleep 600"

darkpool workloads
```

## Development setup

For local development without installing systemd:

```bash
cd darkpool/

# Create a venv with all deps
python3.11 -m venv .venv
.venv/bin/pip install -e main darkpool-cli darkpool-agent

# Set env vars (dev defaults)
cp .env.example .env
# edit .env: DATABASE_URL=sqlite:///./dev.db, ADMIN_PASSWORD=test123

# Run Main
.venv/bin/python -m darkpool_main
# → serves on http://localhost:8000

# In another terminal, simulate an agent:
cd agent/
.venv/bin/python -m darkpool_agent
```

Run tests:

```bash
.venv/bin/python -m pytest main/tests/ agent/tests/ -v
```

## Uninstall

```bash
# Main
sudo systemctl stop darkpool-main
sudo systemctl disable darkpool-main
sudo rm -rf /opt/darkpool/main /etc/systemd/system/darkpool-main.service
sudo systemctl daemon-reload

# Agent
sudo systemctl stop darkpool-agent
sudo systemctl disable darkpool-agent
sudo rm -rf /opt/darkpool/agent /etc/darkpool /etc/systemd/system/darkpool-agent.service
sudo systemctl daemon-reload
```

## Troubleshooting

### Agent won't register

- Check `journalctl -u darkpool-agent -f` for the exact error
- Verify `MAIN_URL` is reachable from the worker: `curl $MAIN_URL/health`
- Verify `REGISTRATION_TOKEN` matches Main's `.env` (re-check `NODE_REGISTRATION_TOKEN`)
- If the token was rotated on Main, the agent's stored token is invalid; re-register

### Main shows worker as OFFLINE

- Check agent is running: `systemctl status darkpool-agent`
- Check agent can reach Main: `curl -k $MAIN_URL/health`
- Check Main's heartbeat threshold: `HEARTBEAT_INTERVAL_SEC` (default 10s)
  vs `OFFLINE_THRESHOLD_SEC` (default 45s) — agent must beat at least
  every 45s

### `darkpool node list` returns 401

- You need an admin token: `darkpool login --username admin --password ...`
- `export DARKPOOL_TOKEN=...` then retry

### Database migrations

v1 uses `Base.metadata.create_all()`. For schema changes, run:
```bash
darkpool-main-db upgrade   # (future)
```

For now, simply drop the DB and re-init for major schema changes:
```bash
sudo systemctl stop darkpool-main
rm /opt/darkpool/main/darkpool.db
sudo systemctl start darkpool-main
```

## Backup

- Main: backup `/opt/darkpool/main/darkpool.db` (SQLite) or schedule a `pg_dump` (PostgreSQL)
- Main: backup `/opt/darkpool/main/.env` (contains the SECRET_KEY — losing it invalidates all sessions)
- Agents: backup `/etc/darkpool/agent.key` (per-node ed25519 private key)

## Upgrades

```bash
cd /opt/darkpool/main  # or /opt/darkpool/agent
git pull
.venv/bin/pip install -e .
sudo systemctl restart darkpool-main  # or darkpool-agent
```
